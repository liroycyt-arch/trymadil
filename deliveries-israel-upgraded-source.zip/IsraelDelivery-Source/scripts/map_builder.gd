extends RefCounted
class_name TelAvivMapBuilder

const ROAD_Y := 0.045
const MAX_STREET_TREES := 140
const MAX_STREET_LAMPS := 54

static func build(parent: Node3D, data: Dictionary) -> Dictionary:
	var lighting := _add_lighting(parent)
	_add_ground(parent)
	var roads: Array = data.get("roads", [])
	var road_instance := MeshInstance3D.new()
	road_instance.name = "כבישים מרחובות תל אביב"
	road_instance.mesh = _make_roads(roads)
	var road_material := StandardMaterial3D.new()
	road_material.vertex_color_use_as_albedo = true
	road_material.roughness = 0.92
	road_instance.material_override = road_material
	parent.add_child(road_instance)
	var sidewalk_instance := MeshInstance3D.new()
	sidewalk_instance.name = "מדרכות"
	sidewalk_instance.mesh = _make_sidewalks(roads)
	var sidewalk_material := StandardMaterial3D.new()
	sidewalk_material.vertex_color_use_as_albedo = true
	sidewalk_material.roughness = 0.98
	sidewalk_instance.material_override = sidewalk_material
	parent.add_child(sidewalk_instance)
	var building_result := _make_buildings(data.get("buildings", []))
	var building_instance := MeshInstance3D.new()
	building_instance.name = "מבני העיר"
	building_instance.mesh = building_result.body
	building_instance.material_override = _vertex_material()
	parent.add_child(building_instance)
	var windows_instance := MeshInstance3D.new()
	windows_instance.name = "חלונות וחזיתות מסחריות"
	windows_instance.mesh = building_result.windows
	windows_instance.material_override = building_result.windows_material
	parent.add_child(windows_instance)
	var block_body := StaticBody3D.new()
	block_body.name = "התנגשויות המבנים"
	var collision := CollisionShape3D.new()
	var shape := ConcavePolygonShape3D.new()
	shape.backface_collision = true
	shape.set_faces(building_result.collision.get_faces())
	collision.shape = shape
	block_body.add_child(collision)
	parent.add_child(block_body)
	_add_street_greenery(parent, roads)
	_add_poi_markers(parent, data.get("pois", []))
	lighting["windows_material"] = building_result.windows_material
	return lighting

static func apply_game_time(lighting: Dictionary, game_minutes: float) -> void:
	var minute := fposmod(game_minutes,1440.0)
	var raw_daylight := maxf(0.0,sin((minute - 360.0) * PI / 720.0))
	var daylight := raw_daylight * raw_daylight * (3.0 - 2.0 * raw_daylight)
	var night := 1.0 - daylight
	var environment: Environment = lighting.get("environment")
	var sky_material: ProceduralSkyMaterial = lighting.get("sky_material")
	var sun: DirectionalLight3D = lighting.get("sun")
	if environment:
		environment.ambient_light_energy = lerpf(0.12,0.72,daylight)
		var horizon := Color("19273d").lerp(Color("f0b77c"),clampf((1.0 - absf(raw_daylight - 0.35) / 0.35),0.0,1.0) * 0.28).lerp(Color("a8c9dc"),daylight)
		environment.ambient_light_color = Color("263652").lerp(Color("d6d0c0"),daylight)
		if environment.background_mode == Environment.BG_COLOR:
			environment.background_color = horizon
	if sky_material:
		sky_material.sky_top_color = Color("101d35").lerp(Color("347eaf"),daylight)
		sky_material.sky_horizon_color = Color("d18d64").lerp(Color("acd2df"),daylight)
		sky_material.ground_bottom_color = Color("111822").lerp(Color("5d655f"),daylight)
		sky_material.ground_horizon_color = Color("38404a").lerp(Color("a7a18d"),daylight)
	if sun:
		sun.rotation_degrees.x = -8.0 - raw_daylight * 72.0
		sun.light_energy = 0.05 + daylight * 1.15
		sun.light_color = Color("ffd09a").lerp(Color("fff2dd"),daylight)
	var windows: StandardMaterial3D = lighting.get("windows_material")
	if windows:
		windows.albedo_color = Color("9cb2c0").lerp(Color("f1bd73"),night * 0.8)
		windows.emission_enabled = true
		windows.emission = Color("ffbb68")
		windows.emission_energy_multiplier = night * 1.2
	for lamp in lighting.get("street_lights",[]):
		var light := lamp as OmniLight3D
		light.light_energy = night * 0.65
		light.visible = night > 0.05

static func _add_lighting(parent: Node3D) -> Dictionary:
	var world := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_material := ProceduralSkyMaterial.new()
	sky.sky_material = sky_material
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color("d6d0c0")
	env.ambient_light_energy = 0.72
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	world.environment = env
	parent.add_child(world)
	var sun := DirectionalLight3D.new()
	sun.name = "שמש מחזורית"
	sun.rotation_degrees = Vector3(-60,-28,0)
	sun.light_color = Color("fff2dd")
	sun.light_energy = 1.1
	sun.shadow_enabled = true
	parent.add_child(sun)
	var lamps: Array[OmniLight3D] = []
	for pos in [Vector3(-300,5,-180),Vector3(-150,5,80),Vector3(0,5,0),Vector3(175,5,-70),Vector3(280,5,210),Vector3(40,5,350),Vector3(-240,5,260),Vector3(330,5,-280)]:
		var light := OmniLight3D.new()
		light.name = "תאורת רחוב לילית"
		light.position = pos
		light.light_color = Color("ffd198")
		light.omni_range = 16.0
		light.light_energy = 0.0
		light.visible = false
		light.shadow_enabled = false
		parent.add_child(light)
		lamps.append(light)
	return {"environment":env,"sky_material":sky_material,"sun":sun,"street_lights":lamps}

static func _add_ground(parent: Node3D) -> void:
	var ground := MeshInstance3D.new()
	ground.name = "קרקע עירונית"
	var plane := PlaneMesh.new()
	plane.size = Vector2(3000,3000)
	ground.mesh = plane
	ground.position.y = -0.12
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color("a8a394")
	mat.roughness = 1.0
	ground.material_override = mat
	parent.add_child(ground)
	var collider := StaticBody3D.new()
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(3000,0.2,3000)
	shape.shape = box
	collider.position.y = -0.22
	collider.add_child(shape)
	parent.add_child(collider)

static func _make_roads(roads: Array) -> ArrayMesh:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for road in roads:
		var kind := str(road.get("kind","residential"))
		var width := float(road.get("width",5.0))
		var color := _road_color(kind)
		var points: Array = road.get("points",[])
		for i in range(points.size()-1):
			var a := Vector2(float(points[i][0]),float(points[i][1]))
			var b := Vector2(float(points[i+1][0]),float(points[i+1][1]))
			var direction := b-a
			if direction.length_squared() < 0.01:
				continue
			var side := Vector2(-direction.y,direction.x).normalized()*width*0.5
			_add_horizontal_quad(st,Vector3(a.x+side.x,ROAD_Y,a.y+side.y),Vector3(b.x+side.x,ROAD_Y,b.y+side.y),Vector3(b.x-side.x,ROAD_Y,b.y-side.y),Vector3(a.x-side.x,ROAD_Y,a.y-side.y),color)
	return st.commit()

static func _make_sidewalks(roads: Array) -> ArrayMesh:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for road in roads:
		var kind := str(road.get("kind",""))
		if kind in ["footway","path","pedestrian","cycleway"]:
			continue
		var width := float(road.get("width",5.0))
		var points: Array = road.get("points",[])
		for i in range(points.size()-1):
			var a := Vector2(float(points[i][0]),float(points[i][1]))
			var b := Vector2(float(points[i+1][0]),float(points[i+1][1]))
			var direction := b-a
			if direction.length_squared() < 0.01:
				continue
			var side := Vector2(-direction.y,direction.x).normalized()
			var curb := width*0.5+0.18
			var edge := curb+2.0
			for sign in [-1.0,1.0]:
				var lane_sign: float = float(sign)
				var a0: Vector2 = a+side*curb*lane_sign; var b0: Vector2 = b+side*curb*lane_sign
				var a1: Vector2 = a+side*edge*lane_sign; var b1: Vector2 = b+side*edge*lane_sign
				var shade := 0.01 if int((a.x+a.y)*0.1)%2 == 0 else -0.015
				_add_horizontal_quad(st,Vector3(a0.x,ROAD_Y+0.004,a0.y),Vector3(b0.x,ROAD_Y+0.004,b0.y),Vector3(b1.x,ROAD_Y+0.004,b1.y),Vector3(a1.x,ROAD_Y+0.004,a1.y),Color(0.63+shade,0.61+shade,0.56+shade))
	return st.commit()

static func _make_buildings(buildings: Array) -> Dictionary:
	var body_st := SurfaceTool.new()
	var collision_st := SurfaceTool.new()
	var window_st := SurfaceTool.new()
	body_st.begin(Mesh.PRIMITIVE_TRIANGLES)
	collision_st.begin(Mesh.PRIMITIVE_TRIANGLES)
	window_st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var rng := RandomNumberGenerator.new()
	rng.seed = 20261023
	for building in buildings:
		var center_data: Array = building.get("center",[0.0,0.0])
		var size_data: Array = building.get("size",[8.0,8.0])
		var center := Vector2(float(center_data[0]),float(center_data[1]))
		var sx := clampf(float(size_data[0])*0.88,4.0,70.0)
		var sz := clampf(float(size_data[1])*0.88,4.0,70.0)
		var height := clampf(float(building.get("height",10.0)),4.0,105.0)
		var style := str(building.get("type","residential"))
		var angle := rng.randf_range(-0.055,0.055)
		var tint := rng.randf_range(-0.07,0.065)
		var base_color := _facade_color(style,tint)
		var y_mid := height*(0.78 if height>22.0 else 1.0)
		var top_sx := sx*(rng.randf_range(0.78,0.96) if height>22.0 else 1.0)
		var top_sz := sz*(rng.randf_range(0.78,0.96) if height>22.0 else 1.0)
		_add_box_faces(body_st,center,angle,sx,0.0,sz,y_mid,base_color)
		if height>22.0:
			_add_box_faces(body_st,center,angle,top_sx,y_mid,top_sz,height,base_color.lightened(0.025))
		else:
			_add_roof_face(body_st,center,angle,sx,sz,height,base_color.lightened(0.06))
		_add_box_faces(collision_st,center,angle,sx,0.0,sz,height,Color.WHITE)
		if rng.randf() < 0.62:
			var floors := clampi(int(height/3.3),1,6)
			var columns_front := clampi(int(sx/5.4),1,4)
			var columns_side := clampi(int(sz/5.4),1,4)
			for floor_index in range(floors):
				var y := 1.5+float(floor_index)*3.1
				if y+1.2 >= y_mid:
					continue
				for column in range(columns_front):
					var x := -sx*0.36+float(column)*((sx*0.72)/maxi(columns_front-1,1))
					_add_window_quad(window_st,center,angle,Vector3(x,y,-sz*0.5-0.025),1.0,1.35,Vector3(0,0,-1),_window_color(rng))
					_add_window_quad(window_st,center,angle,Vector3(x,y,sz*0.5+0.025),1.0,1.35,Vector3(0,0,1),_window_color(rng))
				for column in range(columns_side):
					var z := -sz*0.36+float(column)*((sz*0.72)/maxi(columns_side-1,1))
					_add_window_quad(window_st,center,angle,Vector3(-sx*0.5-0.025,y,z),1.0,1.35,Vector3(-1,0,0),_window_color(rng))
					_add_window_quad(window_st,center,angle,Vector3(sx*0.5+0.025,y,z),1.0,1.35,Vector3(1,0,0),_window_color(rng))
				if floor_index%2==0:
					_add_balcony_rail(body_st,center,angle,sx,y,sz,base_color.darkened(0.12),columns_front)
		if style in ["retail","commercial","shop"] or (str(building.get("name",""))!="" and rng.randf()<0.12):
			_add_storefront(body_st,window_st,center,angle,sx,sz,base_color)
		if rng.randf()<0.28:
			var unit := Vector3(rng.randf_range(0.7,1.4),0.75,rng.randf_range(0.55,0.85))
			_add_box_faces(body_st,center,angle,unit.x, height+unit.y*0.5,unit.z, height+unit.y, Color("9a9b94"))
	var windows_material := StandardMaterial3D.new()
	windows_material.vertex_color_use_as_albedo = true
	windows_material.cull_mode = BaseMaterial3D.CULL_DISABLED
	windows_material.roughness = 0.28
	return {"body":body_st.commit(),"collision":collision_st.commit(),"windows":window_st.commit(),"windows_material":windows_material}

static func _add_box_faces(st: SurfaceTool, center: Vector2, angle: float, sx: float, y0: float, sz: float, y1: float, color: Color, local_offset: Vector3=Vector3.ZERO) -> void:
	var hx:=sx*0.5; var hz:=sz*0.5
	var p000:=Vector3(-hx,y0,-hz)+local_offset; var p100:=Vector3(hx,y0,-hz)+local_offset; var p010:=Vector3(-hx,y1,-hz)+local_offset; var p110:=Vector3(hx,y1,-hz)+local_offset
	var p001:=Vector3(-hx,y0,hz)+local_offset; var p101:=Vector3(hx,y0,hz)+local_offset; var p011:=Vector3(-hx,y1,hz)+local_offset; var p111:=Vector3(hx,y1,hz)+local_offset
	_add_local_face(st,center,angle,p000,p010,p110,p100,Vector3(0,0,-1),color.darkened(0.05))
	_add_local_face(st,center,angle,p101,p111,p011,p001,Vector3(0,0,1),color.darkened(0.08))
	_add_local_face(st,center,angle,p001,p011,p010,p000,Vector3(-1,0,0),color.darkened(0.1))
	_add_local_face(st,center,angle,p100,p110,p111,p101,Vector3(1,0,0),color.lightened(0.025))
	_add_local_face(st,center,angle,p010,p011,p111,p110,Vector3(0,1,0),color.lightened(0.035))

static func _add_roof_face(st: SurfaceTool, center: Vector2, angle: float, sx: float, sz: float, height: float, color: Color) -> void:
	var x:=sx*0.5; var z:=sz*0.5
	_add_local_face(st,center,angle,Vector3(-x,height,-z),Vector3(-x,height,z),Vector3(x,height,z),Vector3(x,height,-z),Vector3.UP,color)

static func _add_local_face(st: SurfaceTool, center: Vector2, angle: float, a: Vector3,b: Vector3,c: Vector3,d: Vector3, normal: Vector3,color: Color) -> void:
	var n2:=Vector2(normal.x,normal.z).rotated(angle)
	var world_normal:=Vector3(n2.x,normal.y,n2.y)
	for vertex in [a,b,c,a,c,d]:
		var p2:=Vector2(vertex.x,vertex.z).rotated(angle)+center
		st.set_normal(world_normal)
		st.set_color(color)
		st.add_vertex(Vector3(p2.x,vertex.y,p2.y))

static func _add_window_quad(st: SurfaceTool, center: Vector2, angle: float, p: Vector3, width: float, height: float, normal: Vector3, color: Color) -> void:
	var u:=Vector3.RIGHT if absf(normal.z)>0.5 else Vector3.FORWARD
	var a:=p-u*width*0.5
	var b:=p+Vector3.UP*height-u*width*0.5
	var c:=p+Vector3.UP*height+u*width*0.5
	var d:=p+u*width*0.5
	_add_local_face(st,center,angle,a,b,c,d,normal,color)

static func _add_balcony_rail(st: SurfaceTool, center: Vector2, angle: float, sx: float, y: float, sz: float, color: Color, count: int) -> void:
	var width:=sx*0.68/float(maxi(count,1))
	for i in range(count):
		var x:=-sx*0.34+(float(i)+0.5)*width
		var offset:=Vector3(x,y,-sz*0.5-0.30)
		_add_box_faces(st,center,angle,width*0.88,-0.07,0.55,0.07,color,offset)
		_add_box_faces(st,center,angle,0.045,0.07,0.10,0.73,color.lightened(0.08),offset+Vector3(-width*0.43,0.0,-0.16))
		_add_box_faces(st,center,angle,0.045,0.07,0.10,0.73,color.lightened(0.08),offset+Vector3(width*0.43,0.0,-0.16))
		_add_box_faces(st,center,angle,width*0.9,0.68,0.10,0.76,color.lightened(0.08),offset+Vector3(0,0,-0.16))

static func _add_storefront(body: SurfaceTool, windows: SurfaceTool, center: Vector2, angle: float, sx: float, sz: float, color: Color) -> void:
	var shop_width:=minf(sx*0.72,9.0)
	_add_window_quad(windows,center,angle,Vector3(0,0.65,-sz*0.5-0.04),shop_width,1.55,Vector3(0,0,-1),Color("547a80"))
	_add_box_faces(body,center,angle,1.0,-0.05,0.12,2.15,color.darkened(0.15),Vector3(sx*0.36,0,-sz*0.5-0.12))
	_add_box_faces(body,center,angle,shop_width+0.25,-0.08,0.12,0.10,Color("c7ae73"),Vector3(0,2.30,-sz*0.5-0.12))

static func _window_color(rng: RandomNumberGenerator) -> Color:
	if rng.randf()<0.16:
		return Color("e2b884")
	return Color("546d7b").lerp(Color("8ea7b0"),rng.randf()*0.45)

static func _facade_color(kind: String, tint: float) -> Color:
	var base:=Color("cec5b4")
	if kind in ["commercial","retail","shop"]:
		base=Color("c5b89f")
	elif kind in ["industrial","warehouse"]:
		base=Color("a9aaa5")
	elif kind in ["church","synagogue","mosque"]:
		base=Color("d1c2a2")
	elif kind=="apartments":
		base=Color("c4b9a7")
	return Color(clampf(base.r+tint,0,1),clampf(base.g+tint,0,1),clampf(base.b+tint,0,1))

static func _add_street_greenery(parent: Node3D, roads: Array) -> void:
	var rng:=RandomNumberGenerator.new()
	rng.seed=918273
	var tree_positions: Array[Vector3]=[]
	var lamp_positions: Array[Vector3]=[]
	var step_index:=0
	for road in roads:
		var kind:=str(road.get("kind",""))
		if kind in ["footway","path","cycleway"]:
			continue
		var width:=float(road.get("width",5.0))
		var points: Array=road.get("points",[])
		for i in range(points.size()-1):
			if tree_positions.size()>=MAX_STREET_TREES and lamp_positions.size()>=MAX_STREET_LAMPS:
				break
			var a:=Vector2(float(points[i][0]),float(points[i][1]))
			var b:=Vector2(float(points[i+1][0]),float(points[i+1][1]))
			var delta:=b-a
			if delta.length()<22.0:
				continue
			step_index+=1
			if step_index%3!=0:
				continue
			var side:=Vector2(-delta.y,delta.x).normalized()
			var amount:=rng.randf_range(0.34,0.67)
			var point:=a.lerp(b,amount)+side*(width*0.5+2.5)*(-1.0 if step_index%2==0 else 1.0)
			if tree_positions.size()<MAX_STREET_TREES and rng.randf()<0.58:
				tree_positions.append(Vector3(point.x,0.0,point.y))
			elif lamp_positions.size()<MAX_STREET_LAMPS:
				lamp_positions.append(Vector3(point.x,0.0,point.y))
	var trees:=Node3D.new()
	trees.name="עצי רחוב"
	parent.add_child(trees)
	_add_multimesh(trees,tree_positions,_tree_trunk_mesh(),Color("786148"),0.6,1.3,1.2)
	_add_multimesh(trees,tree_positions,_tree_canopy_mesh(),Color("4b7752"),1.35,2.8,2.8)
	var lamps:=Node3D.new()
	lamps.name="עמודי תאורת רחוב"
	parent.add_child(lamps)
	_add_multimesh(lamps,lamp_positions,_lamp_mesh(),Color("454a49"),0.12,4.0,2.15)
	_add_multimesh(lamps,lamp_positions,_lamp_head_mesh(),Color("f4d28e"),0.12,4.0,4.25)

static func _add_multimesh(parent: Node3D, positions: Array[Vector3], mesh: Mesh, color: Color, min_scale: float, max_scale: float, y_offset: float=0.0) -> void:
	if positions.is_empty():
		return
	var mm:=MultiMesh.new()
	mm.transform_format=MultiMesh.TRANSFORM_3D
	mm.use_colors=true
	mm.mesh=mesh
	mm.instance_count=positions.size()
	var rng:=RandomNumberGenerator.new()
	rng.seed=321009
	for i in range(positions.size()):
		var scale:=rng.randf_range(min_scale,max_scale)
		var transform:=Transform3D(Basis.IDENTITY.scaled(Vector3(scale,scale,scale)),positions[i]+Vector3(0,y_offset,0))
		mm.set_instance_transform(i,transform)
		var shade:=rng.randf_range(0.83,1.15)
		mm.set_instance_color(i,Color(color.r*shade,color.g*shade,color.b*shade,1))
	var instance:=MultiMeshInstance3D.new()
	instance.multimesh=mm
	var material:=StandardMaterial3D.new()
	material.vertex_color_use_as_albedo=true
	material.roughness=0.92
	instance.material_override=material
	parent.add_child(instance)

static func _tree_trunk_mesh() -> Mesh:
	var mesh:=CylinderMesh.new()
	mesh.top_radius=0.12; mesh.bottom_radius=0.18; mesh.height=2.4
	return mesh

static func _tree_canopy_mesh() -> Mesh:
	var mesh:=SphereMesh.new()
	mesh.radius=0.8; mesh.height=1.5
	return mesh

static func _lamp_mesh() -> Mesh:
	var mesh:=CylinderMesh.new()
	mesh.top_radius=0.045; mesh.bottom_radius=0.08; mesh.height=4.3
	return mesh

static func _lamp_head_mesh() -> Mesh:
	var mesh:=SphereMesh.new()
	mesh.radius=0.17; mesh.height=0.34
	return mesh

static func _add_poi_markers(parent: Node3D, pois: Array) -> void:
	var root:=Node3D.new()
	root.name="עסקים ומקומות בעיר"
	parent.add_child(root)
	var count:=mini(pois.size(),100)
	var step:=maxi(1,int(pois.size()/maxf(1.0,float(count))))
	for i in range(0,pois.size(),step):
		if root.get_child_count()>=count:
			break
		var poi: Dictionary=pois[i]
		var pos: Array=poi.get("position",[0.0,0.0])
		var marker:=MeshInstance3D.new()
		var cylinder:=CylinderMesh.new()
		cylinder.top_radius=0.18; cylinder.bottom_radius=0.25; cylinder.height=0.38
		marker.mesh=cylinder
		marker.position=Vector3(float(pos[0]),0.2,float(pos[1]))
		var mat:=StandardMaterial3D.new()
		mat.albedo_color=Color("e6a736") if str(poi.get("category","")) in ["restaurant","cafe","fast_food"] else Color("5e9a91")
		mat.roughness=0.75
		marker.material_override=mat
		root.add_child(marker)

static func _vertex_material() -> StandardMaterial3D:
	var material:=StandardMaterial3D.new()
	material.vertex_color_use_as_albedo=true
	material.roughness=0.9
	material.cull_mode=BaseMaterial3D.CULL_DISABLED
	return material

static func _add_horizontal_quad(st: SurfaceTool,a: Vector3,b: Vector3,c: Vector3,d: Vector3,color: Color) -> void:
	for vertex in [a,b,c,a,c,d]:
		st.set_normal(Vector3.UP)
		st.set_color(color)
		st.add_vertex(vertex)

static func _road_color(kind: String) -> Color:
	match kind:
		"primary","trunk","secondary": return Color("484c4c")
		"tertiary","unclassified": return Color("575957")
		"pedestrian","footway","path": return Color("a8a192")
		"cycleway": return Color("667c71")
		_: return Color("626463")
