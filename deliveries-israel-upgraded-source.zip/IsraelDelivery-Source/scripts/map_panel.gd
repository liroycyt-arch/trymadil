extends Control
class_name DeliveryMapPanel

signal destination_selected(world_position: Vector2)

var roads: Array = []
var route_points: Array[Vector2] = []
var player_position := Vector2.ZERO
var target_position := Vector2.ZERO
var show_target := false
var full_map := false
var _bounds := Rect2(-1000, -1000, 2000, 2000)

func _ready() -> void:
	if full_map:
		mouse_filter = Control.MOUSE_FILTER_STOP

func configure(map_data: Dictionary) -> void:
	roads = map_data.get("roads", [])
	var found := false
	var min_x := INF; var max_x := -INF; var min_y := INF; var max_y := -INF
	for road in roads:
		for point in road.get("points", []):
			var p := Vector2(float(point[0]), float(point[1]))
			min_x = minf(min_x, p.x); max_x = maxf(max_x, p.x)
			min_y = minf(min_y, p.y); max_y = maxf(max_y, p.y)
			found = true
	if found:
		_bounds = Rect2(min_x, min_y, max_x - min_x, max_y - min_y).grow(35.0)
	queue_redraw()

func set_navigation(player: Vector2, route: Array, target: Vector2, active: bool) -> void:
	var changed := player.distance_squared_to(player_position) >= 0.25 or target.distance_squared_to(target_position) >= 0.25 or active != show_target or route.size() != route_points.size()
	if not changed and route.size() > 1:
		for i in range(route.size()):
			if Vector2(route[i]).distance_squared_to(route_points[i]) > 0.25:
				changed = true
				break
	if not changed:
		return
	player_position = player
	route_points.clear()
	for p in route:
		route_points.append(Vector2(p))
	target_position = target
	show_target = active
	queue_redraw()

func _gui_input(event: InputEvent) -> void:
	if not full_map or not (event is InputEventMouseButton):
		return
	var mouse_event := event as InputEventMouseButton
	if mouse_event.button_index == MOUSE_BUTTON_LEFT and mouse_event.pressed:
		var size := get_rect().size
		var center := size * 0.5
		var scale_factor := minf(size.x / maxf(_bounds.size.x,1.0), size.y / maxf(_bounds.size.y,1.0)) * 0.97
		if scale_factor > 0.0:
			var world := _bounds.get_center() + (get_local_mouse_position() - center) / scale_factor
			destination_selected.emit(world)
			accept_event()

func _draw() -> void:
	var size := get_rect().size
	if size.x <= 0 or size.y <= 0:
		return
	draw_rect(Rect2(Vector2.ZERO, size), Color("102128"), true)
	var center := size * 0.5
	var scale_factor := minf(size.x / maxf(_bounds.size.x,1.0), size.y / maxf(_bounds.size.y,1.0)) * 0.97
	var world_center := _bounds.get_center()
	if not full_map:
		scale_factor = minf(size.x / 440.0, size.y / 330.0)
		world_center = player_position
	var local_roads := PackedVector2Array()
	var collector_roads := PackedVector2Array()
	var major_roads := PackedVector2Array()
	for road in roads:
		var pts: Array = road.get("points", [])
		if pts.size() < 2:
			continue
		var kind := str(road.get("kind", ""))
		var target_lines := major_roads if kind in ["primary", "secondary", "trunk", "tertiary"] else (collector_roads if kind in ["pedestrian", "footway", "path", "cycleway"] else local_roads)
		for i in range(pts.size() - 1):
			target_lines.append(_project(Vector2(float(pts[i][0]),float(pts[i][1])),center,world_center,scale_factor))
			target_lines.append(_project(Vector2(float(pts[i+1][0]),float(pts[i+1][1])),center,world_center,scale_factor))
	draw_multiline(local_roads, Color("46575b"), 1.1 if full_map else 0.65, true)
	draw_multiline(collector_roads, Color("858d86"), 1.0 if full_map else 0.65, true)
	draw_multiline(major_roads, Color("a3a49a"), 1.5 if full_map else 0.9, true)
	if route_points.size() > 1:
		var projected_route := PackedVector2Array()
		for point in route_points:
			projected_route.append(_project(point,center,world_center,scale_factor))
		draw_polyline(projected_route, Color("f3c34b"), 4.0 if full_map else 2.3, true)
	if show_target:
		var t := _project(target_position,center,world_center,scale_factor)
		draw_circle(t, 6.5 if full_map else 4.5, Color("f26f54"))
		draw_arc(t, 9.0 if full_map else 6.0, 0, TAU, 32, Color.WHITE, 1.4, true)
	var p := _project(player_position,center,world_center,scale_factor)
	draw_circle(p, 6.2 if full_map else 4.0, Color("74d8d0"))
	draw_arc(p, 9.0 if full_map else 6.0, 0, TAU, 32, Color.WHITE, 1.5, true)
	if full_map:
		draw_string(ThemeDB.fallback_font, Vector2(10,22), "לחיצה במפה: בחירת יעד ניווט", HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color("f3c34b"))
	draw_rect(Rect2(Vector2.ZERO,size), Color("9eb2b5"), false, 1.5)

func _project(world: Vector2, center: Vector2, world_center: Vector2, scale_factor: float) -> Vector2:
	return center + Vector2(world.x - world_center.x, world.y - world_center.y) * scale_factor
