extends Node3D

const MapBuilder = preload("res://scripts/map_builder.gd")
const RiderScript = preload("res://scripts/player_controller.gd")
const MapPanelScript = preload("res://scripts/map_panel.gd")
const TrafficScript = preload("res://scripts/traffic_system.gd")
const SAVE_PATH := "user://israel_delivery_save.json"
const MAP_PATH := "res://data/tel_aviv_map.json"
const STORE_ITEMS := {"מים":5,"חלב":8,"קפה":12,"ממתק":4,"גלידה":8}

var map_data: Dictionary = {}
var city_lighting: Dictionary = {}
var rider: DeliveryRider
var traffic_system: CityTrafficSystem
var graph_adj: Array = []
var graph_nodes: Array = []
var active_route: Array[Vector2] = []
var route_names: Array[String] = []
var route_target := Vector2.ZERO
var route_active := false
var navigation_label := ""
var navigation_mode := "none"
var free_route_points: Array[Vector2] = []
var free_route_target := Vector2.ZERO
var free_route_active := false
var pickup_position := Vector2.ZERO
var dropoff_position := Vector2.ZERO
var mission_state := 0 # 0 offer, 1 ride to pickup, 2 ride to customer, 3 completed
var mission_id := 0
var mission_restaurant := ""
var mission_pay := 0
var mission_dist := 0.0
var paid_ids: Dictionary = {}
var player_name := "שליח חדש"
var company := "שליח עצמאי"
var vehicle := "אופניים חשמליים"
var balance := 120
var cash_balance := 35
var total_earned := 0
var deliveries_done := 0
var deliveries_declined := 0
var bank_ledger: Array[Dictionary] = []
var delivery_history: Array[Dictionary] = []
var app_messages: Array[String] = []
var show_minimap := true
var first_person := false
var game_minutes := 480.0
var hud_update_accumulator := 0.0
var map_update_accumulator := 0.0
var lighting_update_accumulator := 0.0
var route_recalc_accumulator := 0.0
var phone_clock_label: Label
var hud_clock_label: Label
var boost_status_label: Label
var transaction_amount_input: LineEdit
var inventory: Dictionary = {}
var settings_display_mode := DisplayServer.WINDOW_MODE_WINDOWED
var borderless_window := false
var resolution_choice := 1
var traffic_density := 1
var resolution_picker: OptionButton
var active_map_widget: DeliveryMapPanel
var game_started := false
var is_phone_open := false
var phone_page := "משלוחים"
var is_paused := false
var saved_position := Vector3.ZERO
var toast_timer := 0.0
var autosave_timer := 0.0
var target_marker: Node3D
var ui_root: Control
var title_overlay: Control
var hud: Control
var hud_info: Label
var hud_prompt: Label
var hud_balance: Label
var hud_distance: Label
var mini_map: DeliveryMapPanel
var phone_overlay: Control
var phone_card: PanelContainer
var phone_body: VBoxContainer
var pause_overlay: Control
var order_name_input: LineEdit
var company_picker: OptionButton
var vehicle_picker: OptionButton
var toast_label: Label
var help_label: Label

func _ready() -> void:
	DisplayServer.window_set_title("משלוחים בישראל")
	Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
	_load_map()
	city_lighting = MapBuilder.build(self, map_data)
	MapBuilder.apply_game_time(city_lighting,game_minutes)
	_build_graph()
	_create_rider()
	traffic_system = TrafficScript.new()
	traffic_system.name="תנועת כלי רכב"
	add_child(traffic_system)
	traffic_system.configure(map_data.get("roads",[]),traffic_density,Vector2.ZERO)
	traffic_system.set_game_time(game_minutes)
	_build_ui()
	_show_title()

func _process(delta: float) -> void:
	if game_started and not is_paused:
		game_minutes = fposmod(game_minutes + delta,1440.0)
		lighting_update_accumulator += delta
		hud_update_accumulator += delta
		map_update_accumulator += delta
		route_recalc_accumulator += delta
		autosave_timer += delta
		if autosave_timer >= 15.0:
			autosave_timer = 0.0
			_save_game()
		if lighting_update_accumulator >= 1.0:
			lighting_update_accumulator = 0.0
			MapBuilder.apply_game_time(city_lighting,game_minutes)
			traffic_system.set_game_time(game_minutes)
			_update_clock_labels()
		if hud_update_accumulator >= 0.15:
			hud_update_accumulator = 0.0
			_update_hud()
		if map_update_accumulator >= 0.12:
			map_update_accumulator = 0.0
			_update_minimap()
			_update_target_marker()
		if route_recalc_accumulator >= 2.0:
			route_recalc_accumulator = 0.0
			_recalculate_current_route()
	if toast_timer > 0.0:
		toast_timer -= delta
		if toast_timer <= 0.0 and toast_label:
			toast_label.visible = false
	if game_started and is_phone_open and phone_clock_label:
		phone_clock_label.text = _format_game_time()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		_save_game()
		get_tree().quit()

func _unhandled_input(event: InputEvent) -> void:
	if not game_started:
		return
	if event is InputEventMouseButton or event is InputEventMouseMotion:
		if not is_phone_open and not is_paused:
			rider.handle_camera_event(event)
			if event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
				get_viewport().set_input_as_handled()
	if event is InputEventKey and event.pressed and not event.echo:
		match event.keycode:
			KEY_P:
				_toggle_phone("משלוחים")
				get_viewport().set_input_as_handled()
			KEY_M:
				_toggle_phone("מפה")
				get_viewport().set_input_as_handled()
			KEY_C:
				first_person = not rider.first_person
				rider.set_first_person(first_person)
				_save_game()
				_notify("המצלמה הוחלפה")
				get_viewport().set_input_as_handled()
			KEY_E:
				_interact()
				get_viewport().set_input_as_handled()
			KEY_SHIFT:
				if rider.try_activate_boost():
					_notify("האצה מוגברת הופעלה לחמש שניות")
				get_viewport().set_input_as_handled()
			KEY_ESCAPE:
				if is_phone_open:
					_toggle_phone(phone_page)
				else:
					_toggle_pause()
				get_viewport().set_input_as_handled()

func _load_map() -> void:
	if not FileAccess.file_exists(MAP_PATH):
		push_error("קובץ המפה המקומי חסר")
		map_data = {"roads": [], "buildings": [], "pois": [], "graph_nodes": [], "graph_edges": []}
		return
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(MAP_PATH))
	if parsed is Dictionary:
		map_data = parsed
	else:
		push_error("קובץ המפה המקומי אינו תקין")
		map_data = {"roads": [], "buildings": [], "pois": [], "graph_nodes": [], "graph_edges": []}

func _build_graph() -> void:
	graph_nodes = map_data.get("graph_nodes", [])
	graph_adj.resize(graph_nodes.size())
	for i in range(graph_adj.size()):
		graph_adj[i] = []
	for edge in map_data.get("graph_edges", []):
		var a := int(edge[0]); var b := int(edge[1])
		if a < 0 or b < 0 or a >= graph_adj.size() or b >= graph_adj.size():
			continue
		graph_adj[a].append({"to": b, "distance": float(edge[3]), "name": str(edge[2])})

func _create_rider() -> void:
	rider = RiderScript.new()
	rider.configure(vehicle, company)
	var start_index := _nearest_node(Vector2.ZERO)
	if start_index >= 0:
		var start: Array = graph_nodes[start_index]
		rider.position = Vector3(float(start[0]), 0.04, float(start[1]))
	else:
		rider.position = Vector3(0,0.04,0)
	add_child(rider)

func _build_ui() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 10
	add_child(layer)
	ui_root = Control.new()
	ui_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui_root.layout_direction = Control.LAYOUT_DIRECTION_RTL
	var hebrew_theme: Variant=load("res://assets/fonts/game_theme.tres")
	if hebrew_theme is Theme:
		ui_root.theme=hebrew_theme
	layer.add_child(ui_root)
	_build_title_ui()
	_build_hud()
	_build_phone()
	_build_pause_ui()
	_build_toast()

func _build_title_ui() -> void:
	title_overlay = Control.new()
	title_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui_root.add_child(title_overlay)
	var back := ColorRect.new()
	back.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	back.color = Color("101d22")
	title_overlay.add_child(back)
	var accent := ColorRect.new()
	accent.position = Vector2(0,0)
	accent.size = Vector2(12,900)
	accent.color = Color("e5b43d")
	title_overlay.add_child(accent)
	var panel := _make_card(title_overlay, Vector2(420,605), Vector2(510,145))
	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation", 14)
	panel.add_child(content)
	var badge := Label.new()
	badge.text = "  תל אביב · סימולטור שליחויות  "
	badge.add_theme_font_size_override("font_size", 15)
	badge.modulate = Color("e9bf55")
	badge.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	content.add_child(badge)
	var title := Label.new()
	title.text = "משלוחים בישראל"
	title.add_theme_font_size_override("font_size", 38)
	title.modulate = Color("f6f3e9")
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	content.add_child(title)
	var subtitle := Label.new()
	subtitle.text = "יוצאים לרחוב. אוספים. מוסרים. מרוויחים."
	subtitle.add_theme_font_size_override("font_size", 15)
	subtitle.modulate = Color("b8c5c5")
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	content.add_child(subtitle)
	content.add_child(_separator())
	var name_label := _label("שם השליח", 15, Color("e7ece7"))
	content.add_child(name_label)
	order_name_input = LineEdit.new()
	order_name_input.placeholder_text = "איך קוראים לך?"
	order_name_input.text = player_name if player_name != "שליח חדש" else ""
	order_name_input.max_length = 20
	order_name_input.custom_minimum_size.y = 42
	content.add_child(order_name_input)
	content.add_child(_label("חברת המשלוחים", 15, Color("e7ece7")))
	company_picker = OptionButton.new()
	company_picker.custom_minimum_size.y = 42
	for item in ["שליח עצמאי", "משלוחה", "וולט"]:
		company_picker.add_item(item)
	content.add_child(company_picker)
	content.add_child(_label("כלי התחבורה", 15, Color("e7ece7")))
	vehicle_picker = OptionButton.new()
	vehicle_picker.custom_minimum_size.y = 42
	for item in ["אופניים חשמליים", "קורקינט חשמלי", "קטנוע ישן וחצי שבור"]:
		vehicle_picker.add_item(item)
	content.add_child(vehicle_picker)
	var start_btn := _button("משחק חדש", Callable(self, "_start_new_game"), true)
	content.add_child(start_btn)
	var continue_btn := _button("המשך משחק שמור", Callable(self, "_continue_game"), false)
	content.add_child(continue_btn)
	continue_btn.disabled = not FileAccess.file_exists(SAVE_PATH)
	var attribution := Label.new()
	attribution.text = "נתוני רחובות: OpenStreetMap · © תורמי OpenStreetMap · ODbL"
	attribution.add_theme_font_size_override("font_size", 10)
	attribution.modulate = Color("839595")
	attribution.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	content.add_child(attribution)

func _build_hud() -> void:
	hud = Control.new()
	hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui_root.add_child(hud)
	var top := _make_card(hud, Vector2(320,166), Vector2(22,22))
	hud_info = _label("מוכן ליציאה", 18, Color("f6f3e9"))
	top.add_child(hud_info)
	hud_clock_label = _label("08:00",24,Color("f6f3e9"))
	top.add_child(hud_clock_label)
	hud_balance = _label("בנק: 120 ₪  ·  מזומן: 35 ₪", 15, Color("e9bf55"))
	top.add_child(hud_balance)
	hud_distance = _label("המתן להצעה בטלפון", 13, Color("b8c5c5"))
	top.add_child(hud_distance)
	boost_status_label = _label("האצה מוגברת: מוכנה · Shift",13,Color("b8c5c5"))
	top.add_child(boost_status_label)
	var map_card := _make_card(hud, Vector2(250,190), Vector2(1165,22))
	mini_map = MapPanelScript.new()
	mini_map.custom_minimum_size = Vector2(218,138)
	mini_map.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	map_card.add_child(mini_map)
	mini_map.configure(map_data)
	var attribution := _label("OpenStreetMap · ODbL", 9, Color("aebdbd"))
	attribution.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	map_card.add_child(attribution)
	hud_prompt = Label.new()
	hud_prompt.anchor_left = 0.2; hud_prompt.anchor_right = 0.8
	hud_prompt.anchor_top = 0.80; hud_prompt.anchor_bottom = 0.90
	hud_prompt.offset_left = 0; hud_prompt.offset_right = 0
	hud_prompt.offset_top = 0; hud_prompt.offset_bottom = 0
	hud_prompt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hud_prompt.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	hud_prompt.add_theme_font_size_override("font_size", 22)
	hud_prompt.modulate = Color("fff4d3")
	hud.add_child(hud_prompt)
	help_label = Label.new()
	help_label.anchor_left = 0.0; help_label.anchor_right = 1.0
	help_label.anchor_top = 0.94; help_label.anchor_bottom = 1.0
	help_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	help_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	help_label.text = "W/S נסיעה · A/D פנייה · רווח בלימה · Shift האצה · עכבר ימני סיבוב מצלמה · גלגלת זום · E פעולה · P טלפון · C מצלמה · Esc השהיה"
	help_label.add_theme_font_size_override("font_size", 13)
	help_label.modulate = Color("d4dddc")
	hud.add_child(help_label)
	hud.visible = false

func _build_phone() -> void:
	phone_overlay = Control.new()
	phone_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui_root.add_child(phone_overlay)
	var shade := ColorRect.new()
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.color = Color(0.025,0.055,0.065,0.72)
	phone_overlay.add_child(shade)
	phone_card = _make_card(phone_overlay, Vector2(650,735), Vector2(395,82))
	var layout := VBoxContainer.new()
	layout.add_theme_constant_override("separation", 12)
	phone_card.add_child(layout)
	var header := HBoxContainer.new()
	var title := _label("הטלפון של השליח", 24, Color("f6f3e9"))
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(title)
	phone_clock_label = _label("08:00",18,Color("e9bf55"))
	header.add_child(phone_clock_label)
	header.add_child(_button("סגירה ✕", Callable(self, "_close_phone"), false))
	layout.add_child(header)
	var tabs := GridContainer.new()
	tabs.columns = 5
	for tab in ["משלוחים", "מפה", "הבנק שלי", "שעון", "פרופיל", "כלי תחבורה", "היסטוריה", "הודעות", "חנות", "הגדרות"]:
		var tab_btn := _button(tab, Callable(self, "_phone_tab").bind(tab), tab == phone_page)
		tab_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		tabs.add_child(tab_btn)
	layout.add_child(tabs)
	var sep := _separator()
	layout.add_child(sep)
	phone_body = VBoxContainer.new()
	phone_body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	phone_body.add_theme_constant_override("separation", 10)
	layout.add_child(phone_body)
	phone_overlay.visible = false

func _build_pause_ui() -> void:
	pause_overlay = Control.new()
	pause_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui_root.add_child(pause_overlay)
	var shade := ColorRect.new()
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.color = Color(0.02,0.04,0.05,0.78)
	pause_overlay.add_child(shade)
	var panel := _make_card(pause_overlay, Vector2(400,330), Vector2(520,260))
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 14)
	panel.add_child(box)
	var heading := _label("המשחק בהשהיה", 28, Color("f6f3e9"))
	heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(heading)
	box.add_child(_button("המשך במשחק", Callable(self, "_toggle_pause"), true))
	box.add_child(_button("שמירת משחק", Callable(self, "_save_manual"), false))
	box.add_child(_button("חזרה למסך הפתיחה", Callable(self, "_return_to_title"), false))
	pause_overlay.visible = false

func _build_toast() -> void:
	toast_label = Label.new()
	toast_label.anchor_left = 0.27; toast_label.anchor_right = 0.73
	toast_label.anchor_top = 0.08; toast_label.anchor_bottom = 0.15
	toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	toast_label.add_theme_font_size_override("font_size", 19)
	toast_label.modulate = Color("fff1c9")
	ui_root.add_child(toast_label)
	toast_label.visible = false

func _show_title() -> void:
	title_overlay.visible = true
	hud.visible = false
	phone_overlay.visible = false
	pause_overlay.visible = false

func _start_new_game() -> void:
	player_name = order_name_input.text.strip_edges()
	if player_name.is_empty():
		player_name = "שליח תל אביב"
	company = company_picker.get_item_text(company_picker.selected)
	vehicle = vehicle_picker.get_item_text(vehicle_picker.selected)
	balance = 120
	cash_balance = 35
	total_earned = 0
	deliveries_done = 0
	deliveries_declined = 0
	bank_ledger.clear()
	delivery_history.clear()
	app_messages.clear()
	show_minimap = true
	first_person = false
	game_minutes = 480.0
	inventory.clear()
	free_route_points.clear()
	free_route_active = false
	free_route_target = Vector2.ZERO
	navigation_mode = "none"
	paid_ids.clear()
	mission_state = 0
	rider.configure(vehicle, company)
	rider.set_carrying_package(false)
	var start_index := _nearest_node(Vector2.ZERO)
	if start_index >= 0:
		var p: Array = graph_nodes[start_index]
		rider.global_position = Vector3(float(p[0]),0.04,float(p[1]))
	_begin_game()
	_new_order()
	_notify("שלום %s, המשמרת שלך מתחילה עכשיו" % player_name)
	_save_game()

func _continue_game() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		_notify("לא נמצא משחק שמור")
		return
	var text := FileAccess.get_file_as_string(SAVE_PATH)
	var data = JSON.parse_string(text)
	if not data is Dictionary or int(data.get("version",0)) not in [1,2]:
		_notify("קובץ השמירה אינו נתמך")
		return
	player_name = str(data.get("player_name","שליח תל אביב"))
	company = str(data.get("company","שליח עצמאי"))
	vehicle = str(data.get("vehicle","אופניים חשמליים"))
	balance = maxi(0,int(data.get("balance",120)))
	cash_balance = maxi(0,int(data.get("cash_balance",35)))
	total_earned = maxi(0,int(data.get("total_earned",0)))
	deliveries_done = maxi(0,int(data.get("deliveries_done",0)))
	deliveries_declined = maxi(0,int(data.get("deliveries_declined",0)))
	bank_ledger.clear()
	for entry in _safe_array(data,"ledger"):
		if entry is Dictionary:
			bank_ledger.append(entry)
	delivery_history.clear()
	for entry in _safe_array(data,"delivery_history"):
		if entry is Dictionary:
			delivery_history.append(entry)
	app_messages.clear()
	for message in _safe_array(data,"app_messages"):
		app_messages.append(str(message))
	show_minimap = bool(data.get("show_minimap",true))
	first_person = bool(data.get("first_person",false))
	var saved_minutes: Variant=data.get("game_minutes",480.0)
	game_minutes=fposmod(float(saved_minutes),1440.0) if saved_minutes is int or saved_minutes is float else 480.0
	settings_display_mode = int(data.get("display_mode",DisplayServer.WINDOW_MODE_WINDOWED))
	borderless_window = bool(data.get("borderless_window",false))
	resolution_choice = clampi(int(data.get("resolution_choice",1)),0,2)
	traffic_density = clampi(int(data.get("traffic_density",1)),0,2)
	var loaded_inventory: Variant = data.get("inventory",{})
	inventory = loaded_inventory if loaded_inventory is Dictionary else {}
	free_route_active = bool(data.get("free_route_active",false))
	free_route_target = _vector_from_array(data.get("free_route_target",[0,0]))
	free_route_points.clear()
	for point in _safe_array(data,"free_route_points"):
		if point is Array and point.size()>=2:
			free_route_points.append(_vector_from_array(point))
	navigation_mode = str(data.get("navigation_mode","none"))
	var loaded_paid_ids: Variant = data.get("paid_ids",{})
	paid_ids = loaded_paid_ids if loaded_paid_ids is Dictionary else {}
	mission_state = clampi(int(data.get("mission_state",0)),0,4)
	mission_id = maxi(0,int(data.get("mission_id",0)))
	mission_restaurant = str(data.get("mission_restaurant",""))
	mission_pay = maxi(0,int(data.get("mission_pay",0)))
	mission_dist = maxf(0.0,float(data.get("mission_dist",0.0)))
	pickup_position = _vector_from_array(data.get("pickup",[0,0]))
	dropoff_position = _vector_from_array(data.get("dropoff",[0,0]))
	rider.configure(vehicle,company)
	var saved_position: Variant=data.get("position",[0,0,0])
	if saved_position is Array and saved_position.size()>=3:
		rider.global_position=Vector3(clampf(float(saved_position[0]),-1450.0,1450.0),clampf(float(saved_position[1]),0.0,8.0),clampf(float(saved_position[2]),-1450.0,1450.0))
	else:
		rider.global_position=Vector3.ZERO
	rider.set_carrying_package(mission_state == 2)
	_begin_game()
	if navigation_mode == "free" and free_route_active:
		_restore_free_route()
	elif int(data.get("version",1)) == 1 and mission_state in [1,2]:
		_set_route_for_mission()
	elif navigation_mode == "delivery" and mission_state in [1,2]:
		_set_route_for_mission()
	elif mission_state == 0:
		_new_order()
	_notify("המשחק השמור נטען בהצלחה")

func _begin_game() -> void:
	game_started = true
	is_paused = false
	is_phone_open = false
	title_overlay.visible = false
	hud.visible = true
	pause_overlay.visible = false
	phone_overlay.visible = false
	rider.controls_enabled = true
	rider.set_first_person(first_person)
	if settings_display_mode in [DisplayServer.WINDOW_MODE_WINDOWED,DisplayServer.WINDOW_MODE_FULLSCREEN,DisplayServer.WINDOW_MODE_EXCLUSIVE_FULLSCREEN]:
		DisplayServer.window_set_mode(settings_display_mode)
	DisplayServer.window_set_flag(DisplayServer.WINDOW_FLAG_BORDERLESS,borderless_window)
	if DisplayServer.get_name()!="headless" and settings_display_mode==DisplayServer.WINDOW_MODE_WINDOWED:
		var sizes := [Vector2i(1280,720),Vector2i(1440,900),Vector2i(1920,1080)]
		var screen_size:=DisplayServer.screen_get_size()
		var requested: Vector2i=sizes[clampi(resolution_choice,0,sizes.size()-1)]
		requested.x=mini(requested.x,screen_size.x)
		requested.y=mini(requested.y,screen_size.y)
		DisplayServer.window_set_size(requested)
	if traffic_system:
		traffic_system.set_traffic_density(traffic_density)
		traffic_system.set_game_time(game_minutes)
	_update_clock_labels()
	if mini_map:
		mini_map.get_parent().visible = show_minimap
	_update_hud()

func _new_order() -> void:
	if mission_state in [1,2]:
		return
	mission_id += 1
	mission_state = 0
	var candidates: Array = []
	for poi in map_data.get("pois",[]):
		var category := str(poi.get("category",""))
		if category in ["restaurant","cafe","fast_food"]:
			var pos: Array = poi.get("position",[0,0])
			var p := Vector2(float(pos[0]),float(pos[1]))
			if p.length() > 80.0 and p.length() < 850.0:
				candidates.append({"pos":p,"poi":poi})
	if candidates.is_empty():
		var nearest := _nearest_node(Vector2.ZERO)
		if nearest < 0:
			_notify("לא נמצאו מסעדות זמינות באזור")
			return
		var p0: Array = graph_nodes[nearest]
		pickup_position = Vector2(float(p0[0]),float(p0[1]))
		mission_restaurant = "מטבח רוטשילד"
	else:
		candidates.sort_custom(func(a,b): return Vector2(a.pos).length() < Vector2(b.pos).length())
		var chosen: Dictionary = candidates[mini(1,candidates.size()-1)]
		pickup_position = chosen.pos
		var fictional := ["פלאפל בשדרה", "פיצה לב העיר", "קפה שוק הכרמל", "המטבח של דיזנגוף", "שווארמה נחלת בנימין"]
		mission_restaurant = fictional[(mission_id-1) % fictional.size()]
	var pickup_node := _nearest_node(pickup_position)
	var best_node := pickup_node
	var best_score := -1.0
	for i in range(graph_nodes.size()):
		var p: Array = graph_nodes[i]
		var v := Vector2(float(p[0]),float(p[1]))
		var d := v.distance_to(pickup_position)
		if d > 320.0 and d < 780.0 and d > best_score:
			best_score = d
			best_node = i
	if best_node < 0:
		best_node = _nearest_node(pickup_position + Vector2(430,150))
	var target: Array = graph_nodes[maxi(best_node,0)]
	dropoff_position = Vector2(float(target[0]),float(target[1]))
	var planned_route := _find_route(pickup_position,dropoff_position)
	mission_dist = 0.0
	for i in range(1,planned_route.points.size()):
		mission_dist += planned_route.points[i-1].distance_to(planned_route.points[i])
	if mission_dist <= 0.0:
		mission_dist = pickup_position.distance_to(dropoff_position)
	mission_pay = int(28 + mission_dist * 0.075)
	if navigation_mode != "free":
		_restore_free_route()
	_update_hud()
	_save_game()

func _accept_order() -> void:
	if mission_state != 0:
		return
	mission_state = 1
	_notify("המשלוח התקבל. נוסעים אל %s" % mission_restaurant)
	_save_game()
	_refresh_phone()

func _reject_order() -> void:
	if mission_state != 0:
		return
	deliveries_declined += 1
	mission_state = 4
	if navigation_mode == "delivery":
		_restore_free_route()
	_notify("ההצעה נדחתה. אפשר לבקש הצעה חדשה בטלפון")
	_refresh_phone()
	_save_game()

func _set_route_for_mission() -> void:
	if mission_state == 1:
		_route_to(pickup_position,"נקודת איסוף","delivery")
	elif mission_state == 2:
		_route_to(dropoff_position,"הלקוח","delivery")
	_update_hud()
	_save_game()

func _interact() -> void:
	if not game_started or is_phone_open or is_paused:
		return
	if mission_state == 1:
		if _rider_position_2d().distance_to(pickup_position) <= 18.0:
			_pickup_order()
		else:
			_notify("צריך להתקרב לנקודת האיסוף כדי לקחת את השקית")
	elif mission_state == 2:
		if _rider_position_2d().distance_to(dropoff_position) <= 18.0:
			_deliver_order()
		else:
			_notify("צריך להתקרב לכתובת הלקוח כדי למסור")
	elif mission_state in [0,3,4]:
		var store := _nearest_service(["supermarket","convenience"],_rider_position_2d())
		var bank_service := _nearest_service(["bank","atm"],_rider_position_2d())
		if not store.is_empty() and float(store.distance)<=18.0:
			_toggle_phone("חנות")
		elif not bank_service.is_empty() and float(bank_service.distance)<=18.0:
			_toggle_phone("הבנק שלי")
		else:
			_toggle_phone("משלוחים")

func _pickup_order() -> void:
	var was_following_delivery := navigation_mode=="delivery"
	mission_state = 2
	rider.set_carrying_package(true)
	if was_following_delivery:
		_set_route_for_mission()
	else:
		_update_hud()
		_save_game()
	_notify("המשלוח נאסף. השקית בתיק — ממשיכים ללקוח")
	_save_game()
	_refresh_phone()

func _deliver_order() -> void:
	var transaction_id := "משלוח-%d" % mission_id
	if paid_ids.has(transaction_id):
		_notify("המשלוח הזה כבר זוכה בחשבון")
		return
	var bonus := 12 if mission_dist < 600.0 else 0
	var payment := mission_pay + bonus
	paid_ids[transaction_id] = true
	balance += payment
	total_earned += payment
	deliveries_done += 1
	bank_ledger.push_front({"id":transaction_id,"description":"תשלום עבור משלוח","amount":payment,"time":Time.get_datetime_string_from_system(false,true)})
	delivery_history.push_front({"id":transaction_id,"restaurant":mission_restaurant,"amount":payment,"distance":int(mission_dist),"time":Time.get_datetime_string_from_system(false,true)})
	if delivery_history.size() > 30:
		delivery_history.pop_back()
	mission_state = 3
	rider.set_carrying_package(false)
	if navigation_mode == "delivery":
		_restore_free_route()
	_notify("המשלוח הושלם — נוספו %d ₪ לחשבון" % payment)
	_save_game()
	_refresh_phone()

func _route_to(target: Vector2, label: String, mode: String = "delivery") -> void:
	route_target = target
	navigation_label = label
	navigation_mode = mode
	var start := _rider_position_2d()
	var route_result := _find_route(start,target)
	active_route = route_result.points
	route_names = route_result.names
	route_active = active_route.size() > 1
	if not route_active:
		active_route = [start,target]
		_notify("אין נתיב מחובר זמין באזור. מוצג קו עזר")
	if mini_map:
		mini_map.set_navigation(start,active_route,target,route_active)

func _on_free_destination_selected(position: Vector2) -> void:
	var node_id := _nearest_node(position)
	if node_id < 0:
		_notify("לא נמצאה דרך נגישה באזור הזה")
		return
	var accessible := _node_position(node_id)
	if accessible.distance_to(_rider_position_2d()) < 12.0:
		_notify("בחרו נקודה אחרת במפה כדי לתכנן מסלול")
		return
	var candidate := _find_route(_rider_position_2d(),accessible)
	if candidate.points.size() < 2:
		_notify("לא נמצא מסלול כבישים נגיש ליעד שבחרת")
		return
	free_route_active = true
	free_route_target = accessible
	free_route_points.clear()
	for point in candidate.points:
		free_route_points.append(Vector2(point))
	_route_to(accessible,"יעד עצמאי","free")
	_notify("נבחר יעד נגיש על רשת הרחובות")
	_refresh_phone()
	_save_game()

func _restore_free_route() -> void:
	if free_route_active and free_route_points.size() > 1:
		active_route = free_route_points.duplicate()
		route_target = free_route_target
		navigation_label = "יעד עצמאי"
		route_active = true
		navigation_mode = "free"
		if mini_map:
			mini_map.set_navigation(_rider_position_2d(),active_route,route_target,true)
	else:
		active_route.clear()
		route_active = false
		navigation_mode = "none"
		if mini_map:
			mini_map.set_navigation(_rider_position_2d(),[],Vector2.ZERO,false)

func _cancel_navigation() -> void:
	free_route_active = false
	free_route_points.clear()
	active_route.clear()
	route_active = false
	navigation_mode = "none"
	if mini_map:
		mini_map.set_navigation(_rider_position_2d(),[],Vector2.ZERO,false)
	_notify("הניווט בוטל")
	_refresh_phone()
	_save_game()

func _recalculate_current_route() -> void:
	if not route_active:
		return
	var result := _find_route(_rider_position_2d(),route_target)
	if result.points.size()<2:
		return
	active_route.clear()
	for point in result.points:
		active_route.append(Vector2(point))
	route_names=result.names
	if navigation_mode=="free":
		free_route_points=active_route.duplicate()
		free_route_target=route_target
	if mini_map:
		mini_map.set_navigation(_rider_position_2d(),active_route,route_target,true)

func _find_route(start: Vector2, target: Vector2) -> Dictionary:
	var from_id := _nearest_node(start)
	var to_id := _nearest_node(target)
	if from_id < 0 or to_id < 0:
		return {"points":[],"names":[]}
	if from_id == to_id:
		var single: Array = graph_nodes[from_id]
		return {"points":[Vector2(single[0],single[1])],"names":[]}
	var count := graph_nodes.size()
	var g := PackedFloat32Array(); g.resize(count)
	var came := PackedInt32Array(); came.resize(count)
	var came_name := PackedStringArray(); came_name.resize(count)
	var closed := PackedByteArray(); closed.resize(count)
	for i in range(count):
		g[i] = INF
		came[i] = -1
	g[from_id] = 0.0
	var heap_nodes: Array[int] = []
	var heap_scores: Array[float] = []
	_heap_push(heap_nodes,heap_scores,from_id,_node_position(from_id).distance_to(_node_position(to_id)))
	var loops := 0
	while not heap_nodes.is_empty() and loops < 18000:
		loops += 1
		var current := _heap_pop(heap_nodes,heap_scores)
		var node_id: int = int(current[0])
		if closed[node_id] == 1:
			continue
		closed[node_id] = 1
		if node_id == to_id:
			break
		for edge in graph_adj[node_id]:
			var next_id := int(edge.to)
			if closed[next_id] == 1:
				continue
			var tentative := g[node_id] + float(edge.distance)
			if tentative < g[next_id]:
				g[next_id] = tentative
				came[next_id] = node_id
				came_name[next_id] = str(edge.name)
				var f := tentative + _node_position(next_id).distance_to(_node_position(to_id))
				_heap_push(heap_nodes,heap_scores,next_id,f)
	if came[to_id] < 0:
		return {"points":[],"names":[]}
	var ids: Array[int] = [to_id]
	var names: Array[String] = []
	var cursor := to_id
	while cursor != from_id and cursor >= 0:
		names.push_front(came_name[cursor])
		cursor = came[cursor]
		if cursor >= 0:
			ids.push_front(cursor)
	var points: Array[Vector2] = [start]
	for id in ids:
		points.append(_node_position(id))
	points.append(target)
	return {"points":points,"names":names}

func _heap_push(nodes: Array[int], scores: Array[float], node: int, score: float) -> void:
	var i := nodes.size()
	nodes.append(node); scores.append(score)
	while i > 0:
		var parent := (i-1)/2
		if scores[parent] <= scores[i]:
			break
		var sn := scores[parent]; scores[parent] = scores[i]; scores[i] = sn
		var nn := nodes[parent]; nodes[parent] = nodes[i]; nodes[i] = nn
		i = parent

func _heap_pop(nodes: Array[int], scores: Array[float]) -> Array:
	var result := [nodes[0],scores[0]]
	var last_node: int = nodes.pop_back()
	var last_score: float = scores.pop_back()
	if not nodes.is_empty():
		nodes[0] = last_node; scores[0] = last_score
		var i := 0
		while true:
			var left := i*2+1; var right := left+1; var smallest := i
			if left < nodes.size() and scores[left] < scores[smallest]:
				smallest = left
			if right < nodes.size() and scores[right] < scores[smallest]:
				smallest = right
			if smallest == i:
				break
			var sn := scores[i]; scores[i] = scores[smallest]; scores[smallest] = sn
			var nn := nodes[i]; nodes[i] = nodes[smallest]; nodes[smallest] = nn
			i = smallest
	return result

func _nearest_node(pos: Vector2) -> int:
	var best_id := -1
	var best := INF
	for i in range(graph_nodes.size()):
		var p: Array = graph_nodes[i]
		var d := Vector2(float(p[0]),float(p[1])).distance_squared_to(pos)
		if d < best:
			best = d
			best_id = i
	return best_id

func _node_position(id: int) -> Vector2:
	var p: Array = graph_nodes[id]
	return Vector2(float(p[0]),float(p[1]))

func _rider_position_2d() -> Vector2:
	return Vector2(rider.global_position.x,rider.global_position.z)

func _update_hud() -> void:
	if not hud_info:
		return
	var facing: Vector3=-rider.global_transform.basis.z
	rider.traffic_ahead_distance=traffic_system.nearest_vehicle_ahead(_rider_position_2d(),Vector2(facing.x,facing.z)) if traffic_system else INF
	hud_balance.text = "בנק: %d ₪  ·  מזומן: %d ₪" % [balance,cash_balance]
	if rider.boost_time_left>0.0:
		boost_status_label.text = "האצה מוגברת פעילה · %d שנ׳" % int(ceil(rider.boost_time_left))
		boost_status_label.modulate = Color("f3c34b")
	elif rider.boost_cooldown_left>0.0:
		boost_status_label.text = "האצה מוגברת בטעינה · %d שנ׳" % int(ceil(rider.boost_cooldown_left))
		boost_status_label.modulate = Color("b8c5c5")
	else:
		boost_status_label.text = "האצה מוגברת מוכנה · Shift"
		boost_status_label.modulate = Color("83d9a5")
	var mission_text := "ממתין להצעת משלוח"
	if mission_state == 0:
		mission_text = "יש הצעת משלוח חדשה בטלפון"
	elif mission_state == 1:
		mission_text = "נוסעים לאיסוף: %s" % mission_restaurant
	elif mission_state == 2:
		mission_text = "המשלוח בתיק — נוסעים ללקוח"
	elif mission_state == 3:
		mission_text = "המשלוח הושלם · אפשר לבקש הצעה נוספת בטלפון"
	elif mission_state == 4:
		mission_text = "ההצעה נדחתה · אפשר לבדוק הצעה נוספת בטלפון"
	hud_info.text = "%s  ·  %s קמ״ש" % [vehicle, int(absf(rider.speed_kph))]
	if route_active:
		var route_title := "יעד עצמאי" if navigation_mode=="free" else navigation_label
		if mission_state in [1,2]:
			route_title += " · " + ("יש משלוח לאיסוף" if mission_state==1 else "המשלוח בתיק")
		hud_distance.text = "%s · %d מ׳ · כ-%d דק׳" % [route_title,int(_route_distance(active_route)),_route_eta_minutes(active_route)]
	else:
		hud_distance.text = mission_text
	if mission_state in [1,2]:
		var mission_target := pickup_position if mission_state==1 else dropoff_position
		var dist := _rider_position_2d().distance_to(mission_target)
		hud_prompt.text = "E · %s · עוד %d מ׳" % ["איסוף" if mission_state == 1 else "מסירה", int(dist)] if dist <= 32.0 else "משלוח: %s · %d מ׳" % ["מסעדה" if mission_state==1 else "לקוח",int(dist)]
	elif mission_state == 0:
		hud_prompt.text = "P · בוחרים אם לקבל הצעה  ·  M · מפה לבחירת יעד חופשי"
	elif mission_state == 3:
		hud_prompt.text = "המשלוח הושלם. P · הזמנה חדשה"
	else:
		hud_prompt.text = "P · משלוחים  ·  M · מפה לבחירת יעד עצמאי"
	if route_active and not route_names.is_empty() and not (mission_state in [1,2] and _rider_position_2d().distance_to(pickup_position if mission_state==1 else dropoff_position)<=32.0):
		hud_prompt.text = "המשך ברחוב %s · יעד בעוד %d מ׳" % [route_names[0],int(_rider_position_2d().distance_to(active_route[mini(1,active_route.size()-1)]))]

func _route_distance(points: Array) -> float:
	var distance:=0.0
	for i in range(1,points.size()):
		distance+=Vector2(points[i-1]).distance_to(Vector2(points[i]))
	return distance

func _route_eta_minutes(points: Array) -> int:
	var average_kph:=maxf(12.0,rider.max_speed_kph*0.58)
	return maxi(1,int(ceil(_route_distance(points)*3.6/(average_kph*60.0))))

func _format_game_time() -> String:
	return "%02d:%02d" % [int(game_minutes/60.0)%24,int(game_minutes)%60]

func _time_of_day_label() -> String:
	var hour := int(game_minutes/60.0)%24
	if hour<5:
		return "לילה — הרחובות מוארים"
	if hour<7:
		return "בוקר מוקדם"
	if hour<18:
		return "יום — המשמרת בתל אביב"
	if hour<20:
		return "ערב — האורות מתחילים להידלק"
	return "לילה — הרחובות מוארים"

func _update_clock_labels() -> void:
	var time_text := _format_game_time()
	if hud_clock_label:
		hud_clock_label.text = time_text
	if phone_clock_label:
		phone_clock_label.text = time_text

func _update_minimap() -> void:
	if mini_map:
		var target := route_target if route_active else Vector2.ZERO
		mini_map.set_navigation(_rider_position_2d(),active_route,target,route_active)

func _update_target_marker() -> void:
	if not route_active:
		if is_instance_valid(target_marker):
			target_marker.queue_free()
		target_marker = null
		return
	if is_instance_valid(target_marker):
		target_marker.position = Vector3(route_target.x,0,route_target.y)
		for child in target_marker.get_children():
			if child is Label3D:
				child.text = navigation_label
		return
	target_marker = Node3D.new()
	target_marker.name = "יעד ניווט"
	var pole := MeshInstance3D.new()
	var cylinder := CylinderMesh.new()
	cylinder.top_radius = 0.12; cylinder.bottom_radius = 0.12; cylinder.height = 2.2
	pole.mesh = cylinder; pole.position.y = 1.1
	var material := StandardMaterial3D.new()
	material.albedo_color = Color("edbd40"); material.emission_enabled = true; material.emission = Color("b87515")
	pole.material_override = material
	target_marker.add_child(pole)
	var cap := MeshInstance3D.new()
	var sphere := SphereMesh.new(); sphere.radius = 0.42; sphere.height = 0.84
	cap.mesh = sphere; cap.position.y = 2.35; cap.material_override = material
	target_marker.add_child(cap)
	var label := Label3D.new()
	label.text = navigation_label; label.position.y = 2.9; label.font_size = 36; label.pixel_size = 0.006
	label.modulate = Color("fff1c9"); label.outline_size = 5; label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	target_marker.add_child(label)
	target_marker.position = Vector3(route_target.x,0,route_target.y)
	add_child(target_marker)

func _toggle_phone(page: String) -> void:
	if not game_started:
		return
	if is_paused:
		return
	is_phone_open = not is_phone_open
	if is_phone_open:
		phone_page = page
		phone_overlay.visible = true
		rider.controls_enabled = false
		_refresh_phone()
	else:
		phone_overlay.visible = false
		rider.controls_enabled = true

func _close_phone() -> void:
	is_phone_open = false
	phone_overlay.visible = false
	rider.controls_enabled = true

func _phone_tab(tab: String) -> void:
	phone_page = tab
	_refresh_phone()

func _refresh_phone() -> void:
	if not phone_body:
		return
	for child in phone_body.get_children():
		child.queue_free()
	active_map_widget = null
	var heading := _label(phone_page, 24, Color("f4e9c7"))
	phone_body.add_child(heading)
	match phone_page:
		"משלוחים": _phone_orders()
		"מפה": _phone_map()
		"הבנק שלי": _phone_bank()
		"שעון": _phone_clock()
		"פרופיל": _phone_profile()
		"כלי תחבורה": _phone_vehicle()
		"היסטוריה": _phone_history()
		"הודעות": _phone_messages()
		"חנות": _phone_store()
		"הגדרות": _phone_settings()

func _phone_orders() -> void:
	if mission_state == 0:
		phone_body.add_child(_label("הצעת משלוח חדשה",19,Color("f6f3e9")))
		phone_body.add_child(_label("איסוף: %s" % mission_restaurant,16,Color("cbd5d2")))
		phone_body.add_child(_label("כתובת איסוף: %s" % _closest_street_name(pickup_position),14,Color("cbd5d2")))
		phone_body.add_child(_label("כתובת מסירה: %s" % _closest_street_name(dropoff_position),14,Color("cbd5d2")))
		phone_body.add_child(_label("מרחק משוער: %d מ׳" % int(mission_dist),15,Color("cbd5d2")))
		phone_body.add_child(_label("זמן נסיעה משוער: %d דקות" % maxi(5,int(ceil(mission_dist / 260.0)) + 4),14,Color("cbd5d2")))
		phone_body.add_child(_label("תשלום צפוי: %d ₪  ·  בונוס אפשרי: 12 ₪" % mission_pay,16,Color("e9bf55")))
		phone_body.add_child(_label("קבלה או דחייה — ההזמנה לא מתחילה מעצמה.",13,Color("b8c5c5")))
		var row := HBoxContainer.new()
		row.add_child(_button("קבלת משלוח",Callable(self,"_accept_order"),true))
		row.add_child(_button("דחיית משלוח",Callable(self,"_reject_order"),false))
		phone_body.add_child(row)
	elif mission_state in [1,2]:
		phone_body.add_child(_label("סטטוס: %s" % ("בדרך לאיסוף" if mission_state == 1 else "המשלוח נאסף"),18,Color("f6f3e9")))
		phone_body.add_child(_label("מסעדה: %s" % mission_restaurant,15,Color("cbd5d2")))
		phone_body.add_child(_label("מרחק ליעד: %d מ׳" % int(_rider_position_2d().distance_to(route_target)),15,Color("e9bf55")))
		phone_body.add_child(_button("נווט ל%s" % ("מסעדה" if mission_state == 1 else "לקוח"),Callable(self,"_set_route_for_mission"),true))
		phone_body.add_child(_button("ביצוע אינטראקציה  (E)",Callable(self,"_interact"),false))
	else:
		phone_body.add_child(_label("המשלוח האחרון הושלם בהצלחה." if mission_state == 3 else "אין משלוח פעיל כרגע.",17,Color("cbd5d2")))
		phone_body.add_child(_button("בדיקת משלוחים חדשים",Callable(self,"_new_order"),true))
		phone_body.add_child(_label("אחרי קבלת הזמנה יש לנסוע למסעדה, לאסוף את השקית ולמסור ללקוח.",14,Color("b8c5c5")))

func _phone_map() -> void:
	phone_body.add_child(_label("מפת רחובות מרכז תל אביב · לחצו על נקודה כדי לבחור יעד נגיש",14,Color("cbd5d2")))
	var map := MapPanelScript.new()
	map.custom_minimum_size = Vector2(560,390)
	map.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	map.size_flags_vertical = Control.SIZE_EXPAND_FILL
	map.full_map = true
	map.configure(map_data)
	map.destination_selected.connect(_on_free_destination_selected)
	map.set_navigation(_rider_position_2d(),active_route,route_target,route_active)
	active_map_widget = map
	phone_body.add_child(map)
	if route_active:
		var next_street: String=route_names[0] if not route_names.is_empty() else "המשך בדרך המסומנת"
		var next_point: Vector2=active_route[mini(1,active_route.size()-1)]
		phone_body.add_child(_label("המשך ברחוב %s · פנייה הבאה בעוד %d מ׳" % [next_street,int(_rider_position_2d().distance_to(next_point))],15,Color("f6f3e9")))
		phone_body.add_child(_label("מרחק כולל: %d מ׳ · זמן משוער: %d דקות" % [int(_route_distance(active_route)),_route_eta_minutes(active_route)],14,Color("cbd5d2")))
	if free_route_active:
		phone_body.add_child(_label("יעד עצמאי: %s" % _closest_street_name(free_route_target),14,Color("e9bf55")))
	if mission_state in [1,2]:
		phone_body.add_child(_button("החלפת הניווט ל%s" % ("המסעדה" if mission_state == 1 else "הלקוח"),Callable(self,"_set_route_for_mission"),true))
	if route_active or free_route_active:
		phone_body.add_child(_button("ביטול ניווט",Callable(self,"_cancel_navigation"),false))
	phone_body.add_child(_label("מפה: © OpenStreetMap contributors · Open Database License 1.0",10,Color("aebdbd")))

func _phone_bank() -> void:
	var service := _nearest_service(["bank","atm"],_rider_position_2d())
	var at_service := not service.is_empty() and float(service.distance)<=22.0
	phone_body.add_child(_label("יתרות",14,Color("b8c5c5")))
	phone_body.add_child(_label("בנק: %d ₪  ·  מזומן: %d ₪" % [balance,cash_balance],24,Color("e9bf55")))
	phone_body.add_child(_label("סך הכנסות: %d ₪  ·  משלוחים שהושלמו: %d" % [total_earned,deliveries_done],14,Color("cbd5d2")))
	if service.is_empty():
		phone_body.add_child(_label("לא נמצאה נקודת בנק/כספומט בנתוני המפה המקומיים.",14,Color("b8c5c5")))
	else:
		phone_body.add_child(_label("%s · %d מ׳" % [str(service.name),int(service.distance)],14,Color("cbd5d2")))
		if not at_service:
			phone_body.add_child(_button("ניווט לכספומט או לבנק",Callable(self,"_navigate_to_service").bind(service),true))
	transaction_amount_input = LineEdit.new()
	transaction_amount_input.placeholder_text = "סכום להעברה בשקלים"
	transaction_amount_input.max_length = 8
	transaction_amount_input.custom_minimum_size.y = 40
	transaction_amount_input.alignment = HORIZONTAL_ALIGNMENT_RIGHT
	phone_body.add_child(transaction_amount_input)
	var bank_actions := HBoxContainer.new()
	var deposit_button := _button("הפקדת מזומן",Callable(self,"_transfer_money").bind(true),true)
	var withdrawal_button := _button("משיכת מזומן",Callable(self,"_transfer_money").bind(false),false)
	deposit_button.disabled = not at_service
	withdrawal_button.disabled = not at_service
	bank_actions.add_child(deposit_button)
	bank_actions.add_child(withdrawal_button)
	phone_body.add_child(bank_actions)
	phone_body.add_child(_separator())
	phone_body.add_child(_label("פעולות אחרונות",16,Color("f6f3e9")))
	if bank_ledger.is_empty():
		phone_body.add_child(_label("עדיין לא נרשמו פעולות בחשבון.",14,Color("aebdbd")))
	else:
		for entry in bank_ledger.slice(0,5):
			var amount := int(entry.get("amount",0))
			phone_body.add_child(_label("%s  ·  %s%d ₪" % [str(entry.get("description","פעולה")),"+" if amount>0 else "",amount],14,Color("d2ddd9")))

func _phone_clock() -> void:
	var hours := int(game_minutes/60.0)%24
	var minutes := int(game_minutes)%60
	phone_body.add_child(_label("%02d:%02d" % [hours,minutes],48,Color("e9bf55")))
	phone_body.add_child(_label("קצב המשחק: כל שנייה אמיתית היא דקת משחק אחת",16,Color("cbd5d2")))
	phone_body.add_child(_label("%s" % _time_of_day_label(),18,Color("f6f3e9")))
	phone_body.add_child(_label("שעון הטלפון והשעון במסך המשחק מסונכרנים. ההשהיה עוצרת את הזמן.",14,Color("b8c5c5")))

func _phone_store() -> void:
	var service := _nearest_service(["supermarket","convenience"],_rider_position_2d())
	if service.is_empty():
		phone_body.add_child(_label("לא נמצאה מכולת במפה המקומית.",16,Color("b8c5c5")))
		return
	phone_body.add_child(_label("חנות: %s · %d מ׳" % [str(service.name),int(service.distance)],17,Color("f6f3e9")))
	if float(service.distance)>18.0:
		phone_body.add_child(_label("הרכישה זמינה רק כשמגיעים פיזית לנקודת החנות.",14,Color("b8c5c5")))
		phone_body.add_child(_button("ניווט לחנות הקרובה",Callable(self,"_navigate_to_service").bind(service),true))
		return
	phone_body.add_child(_label("מזומן זמין: %d ₪" % cash_balance,15,Color("e9bf55")))
	for item in STORE_ITEMS:
		var quantity := int(inventory.get(item,0))
		phone_body.add_child(_button("קניית %s · %d ₪ · בתיק: %d" % [item,int(STORE_ITEMS[item]),quantity],Callable(self,"_purchase_store_item").bind(item),true))

func _purchase_store_item(item: String) -> void:
	var service := _nearest_service(["supermarket","convenience"],_rider_position_2d())
	if service.is_empty() or float(service.distance)>18.0:
		_notify("צריך להגיע פיזית למכולת לפני קנייה")
		return
	if not STORE_ITEMS.has(item):
		return
	var cost := int(STORE_ITEMS[item])
	if cash_balance<cost:
		_notify("אין מספיק מזומן — אפשר למשוך כסף בכספומט")
		return
	cash_balance-=cost
	inventory[item]=int(inventory.get(item,0))+1
	bank_ledger.push_front({"description":"רכישת %s" % item,"amount":-cost,"time":Time.get_datetime_string_from_system(false,true)})
	_notify("נרכש %s · %d ₪" % [item,cost])
	_save_game()
	_update_hud()
	_refresh_phone()

func _navigate_to_service(service: Dictionary) -> void:
	if service.has("position"):
		_on_free_destination_selected(Vector2(service.position))

func _nearest_service(categories: Array, from: Vector2) -> Dictionary:
	var best: Dictionary = {}
	var best_distance := INF
	for poi in map_data.get("pois",[]):
		if not str(poi.get("category","")) in categories:
			continue
		var raw: Array = poi.get("position",[0,0])
		var poi_position := Vector2(float(raw[0]),float(raw[1]))
		var node_id := _nearest_node(poi_position)
		if node_id<0:
			continue
		var road_position := _node_position(node_id)
		var distance := from.distance_to(road_position)
		if distance<best_distance:
			best_distance=distance
			best={"name":str(poi.get("name","עסק מקומי")),"position":road_position,"distance":distance,"category":str(poi.get("category",""))}
	return best

func _transfer_money(deposit: bool) -> void:
	var service := _nearest_service(["bank","atm"],_rider_position_2d())
	if service.is_empty() or float(service.distance)>22.0:
		_notify("יש להגיע פיזית לבנק או לכספומט כדי לבצע פעולה")
		return
	if not transaction_amount_input or not transaction_amount_input.text.strip_edges().is_valid_int():
		_notify("יש להזין סכום חיובי בשקלים")
		return
	var amount := int(transaction_amount_input.text.strip_edges())
	if amount <= 0:
		_notify("הסכום חייב להיות גדול מאפס")
		return
	if deposit:
		if amount > cash_balance:
			_notify("אין מספיק מזומן להפקדה")
			return
		cash_balance -= amount
		balance += amount
	else:
		if amount > balance:
			_notify("אין יתרה מספקת למשיכה")
			return
		balance -= amount
		cash_balance += amount
	bank_ledger.push_front({"description":"הפקדת מזומן" if deposit else "משיכת מזומן","amount":amount if deposit else -amount,"time":Time.get_datetime_string_from_system(false,true)})
	transaction_amount_input.text = ""
	_notify("ההעברה הושלמה: %d ₪" % amount)
	_save_game()
	_update_hud()
	_refresh_phone()

func _phone_profile() -> void:
	phone_body.add_child(_label("השליח: %s" % player_name,20,Color("f6f3e9")))
	phone_body.add_child(_label("חברה: %s" % company,15,Color("cbd5d2")))
	phone_body.add_child(_label("דרגה: %s" % ("שליח מתחיל" if deliveries_done < 5 else "שליח פעיל"),16,Color("e9bf55")))
	phone_body.add_child(_label("משלוחים שהושלמו: %d" % deliveries_done,15,Color("cbd5d2")))
	phone_body.add_child(_label("הצעות שנדחו: %d" % deliveries_declined,15,Color("cbd5d2")))
	phone_body.add_child(_label("סך הכסף שהורווח: %d ₪" % total_earned,15,Color("cbd5d2")))

func _phone_vehicle() -> void:
	phone_body.add_child(_label("כלי נוכחי: %s" % vehicle,20,Color("f6f3e9")))
	var speed := int(rider.max_speed_kph)
	var accel := "מהירה" if vehicle == "קורקינט חשמלי" else ("רגועה" if vehicle == "קטנוע ישן וחצי שבור" else "בינונית")
	phone_body.add_child(_label("מהירות מרבית: %d קמ״ש · האצה מוגברת: עד %d קמ״ש" % [speed,int(speed*1.35)],15,Color("cbd5d2")))
	phone_body.add_child(_label("תאוצה: %s" % accel,15,Color("cbd5d2")))
	phone_body.add_child(_label("כלי התחבורה משפיע על התאוצה, הפנייה והמהירות בזמן רכיבה.",14,Color("b8c5c5")))
	phone_body.add_child(_label("בחירת הכלי מתבצעת לפני תחילת משמרת.",14,Color("b8c5c5")))

func _phone_history() -> void:
	phone_body.add_child(_label("משלוחים שהושלמו: %d" % deliveries_done,16,Color("cbd5d2")))
	if delivery_history.is_empty():
		phone_body.add_child(_label("לא הושלמו משלוחים עדיין.",15,Color("aebdbd")))
		return
	for item in delivery_history.slice(0,10):
		phone_body.add_child(_label("%s  ·  %d מ׳  ·  +%d ₪" % [str(item.get("restaurant","משלוח")),int(item.get("distance",0)),int(item.get("amount",0))],14,Color("d2ddd9")))

func _phone_messages() -> void:
	phone_body.add_child(_label("הודעות ועדכונים מהמשמרת",15,Color("cbd5d2")))
	if app_messages.is_empty():
		phone_body.add_child(_label("אין הודעות חדשות.",15,Color("aebdbd")))
	else:
		for message in app_messages.slice(0,8):
			phone_body.add_child(_label("•  %s" % message,14,Color("d2ddd9")))
	var refresh := _button("בקשת הצעת משלוח",Callable(self,"_new_order"),true)
	refresh.disabled = mission_state in [1,2,0]
	phone_body.add_child(refresh)

func _phone_settings() -> void:
	phone_body.add_child(_label("העדפות תצוגה",16,Color("cbd5d2")))
	var map_toggle := CheckButton.new()
	map_toggle.text = "הצגת מפה קטנה במסך המשחק"
	map_toggle.button_pressed = show_minimap
	map_toggle.toggled.connect(_set_minimap_enabled)
	phone_body.add_child(map_toggle)
	var camera_toggle := CheckButton.new()
	camera_toggle.text = "מבט מגוף ראשון"
	camera_toggle.button_pressed = first_person
	camera_toggle.toggled.connect(_set_first_person)
	phone_body.add_child(camera_toggle)
	phone_body.add_child(_separator())
	phone_body.add_child(_label("תצוגה",16,Color("f6f3e9")))
	var display_row := HBoxContainer.new()
	display_row.add_child(_button("חלון",Callable(self,"_apply_display_mode").bind("windowed"),not borderless_window and settings_display_mode==DisplayServer.WINDOW_MODE_WINDOWED))
	display_row.add_child(_button("מסך מלא",Callable(self,"_apply_display_mode").bind("fullscreen"),settings_display_mode==DisplayServer.WINDOW_MODE_FULLSCREEN))
	display_row.add_child(_button("ללא מסגרת",Callable(self,"_apply_display_mode").bind("borderless"),borderless_window))
	phone_body.add_child(display_row)
	resolution_picker = OptionButton.new()
	for resolution in ["1280 × 720","1440 × 900","1920 × 1080"]:
		resolution_picker.add_item(resolution)
	resolution_picker.select(clampi(resolution_choice,0,2))
	phone_body.add_child(resolution_picker)
	phone_body.add_child(_button("החלת רזולוציית חלון",Callable(self,"_apply_resolution"),false))
	phone_body.add_child(_label("צפיפות תנועה",15,Color("f6f3e9")))
	var traffic_row := HBoxContainer.new()
	traffic_row.add_child(_button("דלילה",Callable(self,"_set_traffic_density").bind(0),traffic_density==0))
	traffic_row.add_child(_button("רגילה",Callable(self,"_set_traffic_density").bind(1),traffic_density==1))
	traffic_row.add_child(_button("עמוסה",Callable(self,"_set_traffic_density").bind(2),traffic_density==2))
	phone_body.add_child(traffic_row)
	phone_body.add_child(_label("הגדרות אלה נשמרות עם המשחק. רזולוציית חלון מוגבלת לגודל המסך הזמין.",13,Color("b8c5c5")))

func _set_traffic_density(value: int) -> void:
	traffic_density=clampi(value,0,2)
	if traffic_system:
		traffic_system.set_traffic_density(traffic_density)
	_save_game()
	_refresh_phone()

func _apply_display_mode(mode: String) -> void:
	borderless_window = mode=="borderless"
	settings_display_mode = DisplayServer.WINDOW_MODE_FULLSCREEN if mode=="fullscreen" else DisplayServer.WINDOW_MODE_WINDOWED
	DisplayServer.window_set_flag(DisplayServer.WINDOW_FLAG_BORDERLESS,borderless_window)
	DisplayServer.window_set_mode(settings_display_mode)
	_save_game()
	_refresh_phone()

func _apply_resolution() -> void:
	if resolution_picker:
		resolution_choice = resolution_picker.selected
	var sizes := [Vector2i(1280,720),Vector2i(1440,900),Vector2i(1920,1080)]
	var screen := DisplayServer.screen_get_size()
	var requested: Vector2i = sizes[clampi(resolution_choice,0,sizes.size()-1)]
	requested.x = mini(requested.x,screen.x)
	requested.y = mini(requested.y,screen.y)
	DisplayServer.window_set_flag(DisplayServer.WINDOW_FLAG_BORDERLESS,false)
	borderless_window = false
	settings_display_mode = DisplayServer.WINDOW_MODE_WINDOWED
	DisplayServer.window_set_mode(settings_display_mode)
	DisplayServer.window_set_size(requested)
	DisplayServer.window_set_position((screen-requested)/2)
	_save_game()
	_notify("גודל החלון עודכן")

func _set_minimap_enabled(enabled: bool) -> void:
	show_minimap = enabled
	if mini_map:
		mini_map.get_parent().visible = enabled
	_save_game()

func _set_first_person(enabled: bool) -> void:
	first_person = enabled
	if rider:
		rider.set_first_person(enabled)
	_save_game()

func _closest_street_name(position: Vector2) -> String:
	var closest := INF
	var street := "נקודת מפגש"
	for road in map_data.get("roads",[]):
		for point in road.get("points",[]):
			var p := Vector2(float(point[0]),float(point[1]))
			var distance := p.distance_squared_to(position)
			if distance < closest:
				closest = distance
				street = str(road.get("name",street))
	return street

func _toggle_pause() -> void:
	if not game_started:
		return
	is_paused = not is_paused
	pause_overlay.visible = is_paused
	rider.controls_enabled = not is_paused and not is_phone_open
	get_tree().paused = is_paused
	pause_overlay.process_mode = Node.PROCESS_MODE_ALWAYS

func _return_to_title() -> void:
	if is_paused:
		get_tree().paused = false
	is_paused = false
	game_started = false
	rider.controls_enabled = false
	_save_game()
	_show_title()

func _notify(message: String) -> void:
	app_messages.push_front(message)
	if app_messages.size() > 20:
		app_messages.pop_back()
	if toast_label:
		toast_label.text = message
		toast_label.visible = true
		toast_timer = 3.2

func _save_manual() -> void:
	_save_game(true)

func _save_game(show_toast: bool = false) -> void:
	if not rider:
		return
	var route_json: Array = []
	for point in free_route_points:
		route_json.append([point.x,point.y])
	var data := {
		"version":2,"player_name":player_name,"company":company,"vehicle":vehicle,
		"balance":balance,"cash_balance":cash_balance,"total_earned":total_earned,"deliveries_done":deliveries_done,
		"deliveries_declined":deliveries_declined,"ledger":bank_ledger,"delivery_history":delivery_history,
		"app_messages":app_messages,"show_minimap":show_minimap,"first_person":first_person,"paid_ids":paid_ids,
		"inventory":inventory,"game_minutes":game_minutes,"display_mode":settings_display_mode,"borderless_window":borderless_window,
		"resolution_choice":resolution_choice,"free_route_active":free_route_active,
		"traffic_density":traffic_density,
		"free_route_target":[free_route_target.x,free_route_target.y],"free_route_points":route_json,"navigation_mode":navigation_mode,
		"mission_state":mission_state,"mission_id":mission_id,"mission_restaurant":mission_restaurant,
		"mission_pay":mission_pay,"mission_dist":mission_dist,
		"pickup":[pickup_position.x,pickup_position.y],"dropoff":[dropoff_position.x,dropoff_position.y],
		"position":[rider.global_position.x,rider.global_position.y,rider.global_position.z]
	}
	var temp_path := SAVE_PATH+".tmp"
	var file := FileAccess.open(temp_path,FileAccess.WRITE)
	if not file:
		push_error("לא ניתן ליצור קובץ שמירה זמני")
		return
	file.store_string(JSON.stringify(data,"\t"))
	file.flush()
	file.close()
	var destination := ProjectSettings.globalize_path(SAVE_PATH)
	var temporary := ProjectSettings.globalize_path(temp_path)
	var backup := destination+".bak"
	if FileAccess.file_exists(SAVE_PATH):
		if FileAccess.file_exists(SAVE_PATH+".bak"):
			DirAccess.remove_absolute(backup)
		DirAccess.rename_absolute(destination,backup)
	var rename_error := DirAccess.rename_absolute(temporary,destination)
	if rename_error!=OK:
		if FileAccess.file_exists(SAVE_PATH+".bak"):
			DirAccess.rename_absolute(backup,destination)
		push_error("לא ניתן להחליף את קובץ השמירה: %s" % error_string(rename_error))
		return
	if FileAccess.file_exists(SAVE_PATH+".bak"):
		DirAccess.remove_absolute(backup)
	if show_toast and toast_label and game_started:
		_notify("המשחק נשמר")

func _vector_from_array(value: Variant) -> Vector2:
	return Vector2(float(value[0]),float(value[1])) if value is Array and value.size()>=2 else Vector2.ZERO

func _safe_array(data: Dictionary, key: String) -> Array:
	var value: Variant=data.get(key,[])
	return value if value is Array else []

func _make_card(parent: Control, size: Vector2, pos: Vector2) -> PanelContainer:
	var panel := PanelContainer.new()
	panel.position = pos
	panel.size = size
	panel.custom_minimum_size = size
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.075,0.12,0.14,0.96)
	style.border_color = Color("334a4d")
	style.set_border_width_all(1)
	style.set_corner_radius_all(14)
	style.content_margin_left = 18; style.content_margin_right = 18
	style.content_margin_top = 16; style.content_margin_bottom = 16
	panel.add_theme_stylebox_override("panel",style)
	parent.add_child(panel)
	return panel

func _label(text: String, size: int, color: Color) -> Label:
	var label := Label.new()
	label.text = text
	label.add_theme_font_size_override("font_size",size)
	label.modulate = color
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	label.layout_direction = Control.LAYOUT_DIRECTION_RTL
	return label

func _button(text: String, action: Callable, primary: bool) -> Button:
	var button := Button.new()
	button.text = text
	button.custom_minimum_size = Vector2(0,42)
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	button.add_theme_font_size_override("font_size",15)
	button.layout_direction = Control.LAYOUT_DIRECTION_RTL
	var style := StyleBoxFlat.new()
	style.bg_color = Color("d8ad3e") if primary else Color("1b3035")
	style.border_color = Color("eac45c") if primary else Color("40575b")
	style.set_border_width_all(1)
	style.set_corner_radius_all(9)
	style.content_margin_left = 12; style.content_margin_right = 12
	style.content_margin_top = 8; style.content_margin_bottom = 8
	button.add_theme_stylebox_override("normal",style)
	var hover := style.duplicate()
	hover.bg_color = Color("efc955") if primary else Color("284249")
	button.add_theme_stylebox_override("hover",hover)
	button.add_theme_color_override("font_color",Color("172329") if primary else Color("edf1ea"))
	button.pressed.connect(action)
	return button

func _separator() -> HSeparator:
	var line := HSeparator.new()
	line.add_theme_constant_override("separation",4)
	return line
