extends Node3D
class_name CityTrafficSystem

const VEHICLE_ROAD_KINDS := ["motorway","trunk","primary","secondary","tertiary","residential","unclassified","service","living_street","road"]
const VEHICLE_CAPACITY := 16
const DENSITY_COUNTS := [3,8,14]

var lanes: Array[Dictionary] = []
var endpoint_routes: Dictionary = {}
var vehicles: Array[Dictionary] = []
var traffic_density := 1
var game_minutes := 480.0
var simulation_accumulator := 0.0
var _rng := RandomNumberGenerator.new()

func configure(roads: Array, density: int, origin: Vector2) -> void:
	traffic_density=clampi(density,0,2)
	_rng.seed=70429
	_build_roads(roads)
	for i in range(VEHICLE_CAPACITY):
		var car := _create_vehicle(i)
		add_child(car)
		vehicles.append({"node":car,"path":[],"route_id":-1,"segment":0,"forward":true,"speed":0.0,"distance_left":0.0})
		_spawn_vehicle(i,origin)

func _process(delta: float) -> void:
	simulation_accumulator+=delta
	if simulation_accumulator<0.05:
		return
	var step:=simulation_accumulator
	simulation_accumulator=0.0
	var target_count: int=DENSITY_COUNTS[traffic_density]
	var hour:=int(game_minutes/60.0)%24
	if hour>=0 and hour<5:
		target_count=maxi(2,int(target_count*0.4))
	elif (hour>=7 and hour<=9) or (hour>=16 and hour<=19):
		target_count=mini(VEHICLE_CAPACITY,int(ceil(target_count*1.15)))
	for i in range(vehicles.size()):
		var vehicle: Dictionary=vehicles[i]
		var node: Node3D=vehicle.node
		if i>=target_count:
			node.visible=false
			continue
		node.visible=true
		_advance_vehicle(vehicle,step)

func set_game_time(minutes: float) -> void:
	game_minutes=fposmod(minutes,1440.0)

func set_traffic_density(value: int) -> void:
	traffic_density=clampi(value,0,2)

func nearest_vehicle_ahead(position: Vector2, forward: Vector2) -> float:
	var nearest:=INF
	var heading:=forward.normalized()
	for vehicle in vehicles:
		if not vehicle.node.visible:
			continue
		var world_position: Vector3=vehicle.node.global_position
		var car_pos:=Vector2(world_position.x,world_position.z)
		var offset:=car_pos-position
		var longitudinal:=offset.dot(heading)
		var lateral:=absf(offset.x*heading.y-offset.y*heading.x)
		if longitudinal>0.0 and lateral<2.2:
			nearest=minf(nearest,longitudinal)
	return nearest

func _build_roads(roads: Array) -> void:
	lanes.clear()
	endpoint_routes.clear()
	for road in roads:
		if not str(road.get("kind","")) in VEHICLE_ROAD_KINDS:
			continue
		var raw_points: Array=road.get("points",[])
		if raw_points.size()<2:
			continue
		var points: Array[Vector2]=[]
		for raw in raw_points:
			points.append(Vector2(float(raw[0]),float(raw[1])))
		if _path_length(points)<22.0:
			continue
		var route_id:=lanes.size()
		var lane: Dictionary={"points":points,"oneway":bool(road.get("oneway",false)),"name":str(road.get("name",""))}
		lanes.append(lane)
		var start_key:=_point_key(points[0])
		var end_key:=_point_key(points[points.size()-1])
		if not endpoint_routes.has(start_key):
			endpoint_routes[start_key]=[]
		if not endpoint_routes.has(end_key):
			endpoint_routes[end_key]=[]
		endpoint_routes[start_key].append({"route_id":route_id,"at_start":true})
		endpoint_routes[end_key].append({"route_id":route_id,"at_start":false})

func _spawn_vehicle(index: int, near_point: Vector2) -> void:
	if lanes.is_empty():
		return
	var best_route:=0
	var best_distance:=INF
	var candidates: Array[int]=[]
	for i in range(lanes.size()):
		var points: Array[Vector2]=lanes[i].points
		var midpoint: Vector2=points[int(points.size()/2)]
		var distance:=midpoint.distance_squared_to(near_point)
		if distance<best_distance:
			best_distance=distance
			best_route=i
		if distance<420.0*420.0:
			candidates.append(i)
	var route_id:=best_route if index<3 or candidates.is_empty() else candidates[_rng.randi_range(0,candidates.size()-1)]
	var lane: Dictionary=lanes[route_id]
	var forward:=not bool(lane.oneway) or _rng.randi_range(0,1)==0
	var path: Array[Vector2]=lane.points.duplicate()
	if not forward:
		path.reverse()
	var start_segment:=_rng.randi_range(0,maxi(0,path.size()-2))
	var vehicle: Dictionary=vehicles[index]
	vehicle.path=path
	vehicle.route_id=route_id
	vehicle.forward=forward
	vehicle.segment=start_segment
	vehicle.speed=_rng.randf_range(3.4,6.6)
	vehicle.distance_left=0.0
	var point: Vector2=path[start_segment]
	vehicle.node.position=Vector3(point.x,0.03,point.y)
	vehicles[index]=vehicle

func _advance_vehicle(vehicle: Dictionary, delta: float) -> void:
	if vehicle.path.is_empty() or vehicle.segment>=vehicle.path.size()-1:
		_choose_next_route(vehicle)
	var path: Array[Vector2]=vehicle.path
	var segment_index:=int(vehicle.segment)
	var a: Vector2=path[segment_index]
	var b: Vector2=path[segment_index+1]
	var segment_length:=a.distance_to(b)
	if segment_length<0.2:
		vehicle.segment+=1
		vehicles[_vehicle_index(vehicle)]=vehicle
		return
	var speed_factor:=0.7
	var hour:=int(game_minutes/60.0)%24
	if hour>=7 and hour<20:
		speed_factor=1.0
	if (hour>=7 and hour<=9) or (hour>=16 and hour<=19):
		speed_factor=0.82
	var travel:=float(vehicle.speed)*speed_factor*delta+float(vehicle.distance_left)
	var fraction:=minf(travel/segment_length,1.0)
	var point:=a.lerp(b,fraction)
	var direction: Vector2=(b-a).normalized()
	vehicle.node.position=Vector3(point.x,0.03,point.y)
	vehicle.node.rotation.y=atan2(-direction.x,-direction.y)
	if travel>=segment_length:
		vehicle.segment+=1
		vehicle.distance_left=travel-segment_length
		if int(vehicle.segment)>=path.size()-1:
			_choose_next_route(vehicle)
	else:
		vehicle.distance_left=0.0
	vehicles[_vehicle_index(vehicle)]=vehicle

func _choose_next_route(vehicle: Dictionary) -> void:
	var old_route:=int(vehicle.route_id)
	if old_route<0 or old_route>=lanes.size():
		_spawn_vehicle(_vehicle_index(vehicle),Vector2(vehicle.node.position.x,vehicle.node.position.z))
		return
	var old_lane: Dictionary=lanes[old_route]
	var at_start:=not bool(vehicle.forward)
	var endpoint: Vector2=old_lane.points[0] if at_start else old_lane.points[old_lane.points.size()-1]
	var exits: Array=endpoint_routes.get(_point_key(endpoint),[])
	var choices: Array[Dictionary]=[]
	for exit in exits:
		var route_id:=int(exit.route_id)
		if route_id==old_route:
			continue
		var lane: Dictionary=lanes[route_id]
		var enters_at_start:=bool(exit.at_start)
		if enters_at_start or not bool(lane.oneway):
			choices.append({"route_id":route_id,"forward":enters_at_start})
	if choices.is_empty():
		if not bool(old_lane.oneway):
			vehicle.path=old_lane.points.duplicate()
			vehicle.path.reverse()
			vehicle.forward=not bool(vehicle.forward)
		else:
			vehicle.path=old_lane.points.duplicate()
			vehicle.forward=true
		vehicle.segment=0
		vehicle.distance_left=0.0
		return
	var selected: Dictionary=choices[_rng.randi_range(0,choices.size()-1)]
	var next_id:=int(selected.route_id)
	var next_lane: Dictionary=lanes[next_id]
	var next_forward:=bool(selected.forward)
	var next_path: Array[Vector2]=next_lane.points.duplicate()
	if not next_forward:
		next_path.reverse()
	vehicle.path=next_path
	vehicle.route_id=next_id
	vehicle.forward=next_forward
	vehicle.segment=0
	vehicle.distance_left=0.0

func _create_vehicle(index: int) -> Node3D:
	var car:=Node3D.new()
	car.name="רכב תנועה %02d" % (index+1)
	var body:=_material(Color("62686b"))
	var cabin:=_material(Color("8aa3a8"))
	var dark:=_material(Color("25282a"))
	var glass:=_material(Color("b5ced1"))
	var lights:=_material(Color("f4d693"))
	var colors: Array[Color]=[Color("f1eee1"),Color("4a6e76"),Color("999183"),Color("28444e"),Color("b45c48"),Color("d2c6a5"),Color("475550"),Color("ededdf")]
	body=_material(colors[index%colors.size()])
	_add_box(car,Vector3(1.78,0.63,3.8),Vector3(0,0.55,0.0),body)
	_add_box(car,Vector3(1.50,0.68,1.95),Vector3(0,1.13,-0.15),cabin)
	_add_box(car,Vector3(1.30,0.44,0.06),Vector3(0,1.15,-1.16),glass)
	_add_box(car,Vector3(1.30,0.44,0.06),Vector3(0,1.15,0.84),glass)
	for side in [-1.0,1.0]:
		for fore in [-1.0,1.0]:
			var wheel:=MeshInstance3D.new()
			var torus:=TorusMesh.new()
			torus.inner_radius=0.23; torus.outer_radius=0.31
			wheel.mesh=torus
			wheel.rotation.z=PI*0.5
			wheel.position=Vector3(float(side)*0.89,0.32,float(fore)*1.2)
			wheel.material_override=dark
			car.add_child(wheel)
		var lamp_color:=lights if side<0.0 else _material(Color("d9473f"))
		_add_box(car,Vector3(0.12,0.12,0.08),Vector3(float(side)*0.64,0.67,-1.94),lamp_color)
	return car

func _add_box(parent: Node3D, size: Vector3, at: Vector3, material: Material) -> void:
	var instance:=MeshInstance3D.new()
	var mesh:=BoxMesh.new()
	mesh.size=size
	instance.mesh=mesh
	instance.position=at
	instance.material_override=material
	parent.add_child(instance)

func _material(color: Color) -> StandardMaterial3D:
	var material:=StandardMaterial3D.new()
	material.albedo_color=color
	material.roughness=0.65
	return material

func _path_length(path: Array[Vector2]) -> float:
	var total:=0.0
	for i in range(1,path.size()):
		total+=path[i-1].distance_to(path[i])
	return total

func _point_key(point: Vector2) -> String:
	return "%.2f,%.2f" % [point.x,point.y]

func _vehicle_index(vehicle: Dictionary) -> int:
	for i in range(vehicles.size()):
		if vehicles[i].node==vehicle.node:
			return i
	return -1
