extends SceneTree

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var game: Node = load("res://scenes/main.tscn").instantiate()
	root.add_child(game)
	await process_frame
	if game.map_data.get("roads",[]).size()<1000 or game.graph_nodes.size()<3000:
		_fail("מפת הכבישים או גרף הניווט המקומי לא נטענו")
		return
	if game.traffic_system.lanes.is_empty() or game.traffic_system.vehicles.size()!=16:
		_fail("תנועת כלי הרכב לא נבנתה מנתוני הכבישים")
		return
	var traffic_vehicle: Node3D=game.traffic_system.vehicles[0].node
	var traffic_before: Vector3=traffic_vehicle.global_position
	await create_timer(0.25).timeout
	if traffic_vehicle.global_position.distance_to(traffic_before)<0.05:
		_fail("כלי הרכב בתנועה אינם נוסעים על דרכי העיר")
		return
	game.order_name_input.text="בדיקת מערכת"
	game.company_picker.select(1)
	game.vehicle_picker.select(1)
	game._start_new_game()
	await process_frame
	if game.mission_state!=0 or game.rider.vehicle_name!="קורקינט חשמלי" or game.route_active:
		_fail("התחלת משחק או בחירת הכלי לא פעלה")
		return

	var farthest_position:=Vector2.ZERO
	var farthest_distance:=0.0
	for node in game.graph_nodes:
		var candidate:=Vector2(float(node[0]),float(node[1]))
		var distance:=candidate.distance_squared_to(game._rider_position_2d())
		if distance>farthest_distance:
			farthest_distance=distance
			farthest_position=candidate
	game._on_free_destination_selected(farthest_position)
	if not game.free_route_active or not game.route_active or game.navigation_mode!="free" or game.active_route.size()<2:
		_fail("לא חושב ניווט חופשי על רשת הרחובות")
		return
	var independent_target: Vector2=game.free_route_target
	game._reject_order()
	if game.mission_state!=4 or game.navigation_mode!="free" or game.route_target.distance_to(independent_target)>1.0:
		_fail("דחיית הצעה ביטלה את הניווט העצמאי")
		return
	game._new_order()
	if game.mission_state!=0 or game.navigation_mode!="free":
		_fail("הצעה חדשה דרסה את הניווט העצמאי")
		return
	game._accept_order()
	if game.mission_state!=1 or game.navigation_mode!="free" or game.route_target.distance_to(independent_target)>1.0:
		_fail("קבלת הצעה דרסה את הניווט העצמאי")
		return
	game._set_route_for_mission()
	if game.navigation_mode!="delivery" or not game.route_active:
		_fail("כפתור ניווט למשלוח לא העביר לנתיב משלוח")
		return

	if not game.rider.try_activate_boost() or game.rider.boost_time_left<=0.0 or game.rider.try_activate_boost():
		_fail("האצה מוגברת או נעילת זמן הפעילויות אינן תקינות")
		return
	var original_yaw: float=game.rider._third_pivot.rotation.y
	var press:=InputEventMouseButton.new()
	press.button_index=MOUSE_BUTTON_RIGHT
	press.pressed=true
	game.rider.handle_camera_event(press)
	var motion:=InputEventMouseMotion.new()
	motion.relative=Vector2(40,-12)
	game.rider.handle_camera_event(motion)
	var release:=InputEventMouseButton.new()
	release.button_index=MOUSE_BUTTON_RIGHT
	release.pressed=false
	game.rider.handle_camera_event(release)
	if is_equal_approx(original_yaw,game.rider._third_pivot.rotation.y):
		_fail("סיבוב מצלמה בעכבר לא שינה את כיוון המצלמה")
		return

	game.rider.global_position=Vector3(game.pickup_position.x,0.05,game.pickup_position.y)
	game._interact()
	if game.mission_state!=2 or not game.rider.carrying_package:
		_fail("איסוף המשלוח לא התקדם למסירה")
		return
	game.rider.global_position=Vector3(game.dropoff_position.x,0.05,game.dropoff_position.y)
	game._interact()
	if game.mission_state!=3 or game.deliveries_done!=1 or game.rider.carrying_package or game.delivery_history.size()!=1:
		_fail("מסירת המשלוח או רישום התשלום נכשלו")
		return
	if game.navigation_mode!="free" or not game.free_route_active or game.route_target.distance_to(independent_target)>1.0:
		_fail("ניווט עצמאי לא שוחזר אחרי המסירה")
		return
	var paid_balance: int=game.balance
	game._deliver_order()
	if game.balance!=paid_balance or game.deliveries_done!=1:
		_fail("המערכת אפשרה תשלום כפול")
		return

	var shop: Dictionary=game._nearest_service(["supermarket","convenience"],game._rider_position_2d())
	if shop.is_empty():
		_fail("לא אותרה חנות מתוך נתוני המפה המקומיים")
		return
	var cash_before: int=game.cash_balance
	game.rider.global_position=Vector3(shop.position.x,0.05,shop.position.y)
	game._purchase_store_item("מים")
	if game.cash_balance!=cash_before-5 or int(game.inventory.get("מים",0))!=1:
		_fail("רכישת מוצר לא חייבה מזומן או לא נשמרה במלאי")
		return

	var bank_service: Dictionary=game._nearest_service(["bank","atm"],game._rider_position_2d())
	if bank_service.is_empty():
		_fail("לא אותר בנק או כספומט בנתוני המפה")
		return
	game.rider.global_position=Vector3(bank_service.position.x,0.05,bank_service.position.y)
	game._toggle_phone("הבנק שלי")
	game.transaction_amount_input.text="10"
	var cash_before_transfer: int=game.cash_balance
	var bank_before_transfer: int=game.balance
	game._transfer_money(true)
	if game.cash_balance!=cash_before_transfer-10 or game.balance!=bank_before_transfer+10:
		_fail("הפקדת מזומן לא שמרה על סכומים מדויקים")
		return
	game.transaction_amount_input.text="4"
	var cash_before_withdraw: int=game.cash_balance
	var bank_before_withdraw: int=game.balance
	game._transfer_money(false)
	if game.cash_balance!=cash_before_withdraw+4 or game.balance!=bank_before_withdraw-4:
		_fail("משיכת מזומן לא שמרה על סכומים מדויקים")
		return
	var cash_after_valid: int=game.cash_balance
	var bank_after_valid: int=game.balance
	game.transaction_amount_input.text="999999"
	game._transfer_money(false)
	if game.cash_balance!=cash_after_valid or game.balance!=bank_after_valid:
		_fail("משיכה מעבר ליתרה יצרה או שינתה כסף")
		return
	game._close_phone()
	game.game_minutes=1271.0
	TelAvivMapBuilder.apply_game_time(game.city_lighting,game.game_minutes)
	var night_energy: float=game.city_lighting.environment.ambient_light_energy
	TelAvivMapBuilder.apply_game_time(game.city_lighting,720.0)
	var day_energy: float=game.city_lighting.environment.ambient_light_energy
	if day_energy<=night_energy:
		_fail("מחזור יום/לילה לא שינה את תאורת העיר")
		return
	game.game_minutes=1271.0
	game._update_clock_labels()
	if game.hud_clock_label.text!=game.phone_clock_label.text or game.hud_clock_label.text!="21:11":
		_fail("שעון המשחק והטלפון אינם מסונכרנים בפורמט 24 שעות")
		return
	game._set_traffic_density(2)
	game._save_game()
	if not FileAccess.file_exists("user://israel_delivery_save.json"):
		_fail("קובץ שמירה לא נוצר")
		return
	var saved: Variant=JSON.parse_string(FileAccess.get_file_as_string("user://israel_delivery_save.json"))
	if not saved is Dictionary or int(saved.get("version",0))!=2 or int(saved.get("balance",0))!=game.balance:
		_fail("נתוני הגרסה החדשה לא נשמרו כראוי")
		return
	if float(saved.get("game_minutes",0.0))<1270.0 or not bool(saved.get("free_route_active",false)) or saved.get("inventory",{}).get("מים",0)!=1:
		_fail("שעון, יעד או מלאי לא נשמרו")
		return

	game._set_minimap_enabled(false)
	if game.mini_map.get_parent().visible:
		_fail("הגדרת המפה הקטנה לא פעלה")
		return
	game._set_minimap_enabled(true)
	game._set_first_person(true)
	if not game.rider.first_person:
		_fail("הגדרת גוף ראשון לא פעלה")
		return
	game._set_first_person(false)
	game._toggle_phone("היסטוריה")
	game._phone_tab("שעון")
	if game.phone_page!="שעון" or game.phone_body.get_child_count()==0:
		_fail("אפליקציית השעון אינה פעילה")
		return
	game._phone_tab("מפה")
	if game.active_map_widget==null:
		_fail("מפת הטלפון לא נוצרה")
		return
	game._close_phone()
	game._return_to_title()
	game._continue_game()
	if game.balance!=paid_balance+6 or game.deliveries_done!=1 or game.delivery_history.size()!=1 or not game.free_route_active or int(game.inventory.get("מים",0))!=1 or game.traffic_density!=2:
		_fail("המשך משחק לא שיחזר כסף, מלאי, משלוחים וניווט")
		return
	var good_save:=FileAccess.get_file_as_string("user://israel_delivery_save.json")
	var corrupt_file:=FileAccess.open("user://israel_delivery_save.json",FileAccess.WRITE)
	corrupt_file.store_string("{\"version\":2,\"position\":\"bad\",\"ledger\":\"bad\",\"free_route_points\":\"bad\",\"pickup\":\"bad\",\"dropoff\":null}")
	corrupt_file.close()
	game._continue_game()
	if not game.game_started:
		_fail("שמירה עם שדות פגומים גרמה לשגיאה בטעינה")
		return
	var restore_file:=FileAccess.open("user://israel_delivery_save.json",FileAccess.WRITE)
	restore_file.store_string(good_save)
	restore_file.close()
	game._continue_game()
	if game.balance!=paid_balance+6 or game.traffic_density!=2:
		_fail("לא ניתן היה לטעון שמירה תקינה אחרי בדיקת שחיתות")
		return
	var previous_minutes: float=game.game_minutes
	game._process(1.0)
	if absf(game.game_minutes-fposmod(previous_minutes+1.0,1440.0))>0.001:
		_fail("קצב השעון אינו דקת משחק אחת לכל שנייה")
		return
	game.is_paused=true
	var paused_minutes: float=game.game_minutes
	game._process(1.0)
	game.is_paused=false
	if absf(game.game_minutes-paused_minutes)>0.001:
		_fail("השעון התקדם בזמן השהיה")
		return
	var legacy_file:=FileAccess.open("user://israel_delivery_save.json",FileAccess.WRITE)
	legacy_file.store_string("{\"version\":1,\"player_name\":\"שליח ותיק\",\"balance\":77,\"mission_state\":3,\"position\":[0,0.05,0]}")
	legacy_file.close()
	game._continue_game()
	if game.balance!=77 or game.player_name!="שליח ותיק" or not game.game_started:
		_fail("שמירת גרסה 1 לא הועברה בצורה בטוחה")
		return
	restore_file=FileAccess.open("user://israel_delivery_save.json",FileAccess.WRITE)
	restore_file.store_string(good_save)
	restore_file.close()
	game._continue_game()
	print("עברה: עיר וגרף כבישים, תנועת כלי רכב, שימור ניווט אחרי דחייה, קבלה מפורשת, מסירה פעם אחת ושחזור מסלול, Boost/מצלמה, חנות פיזית, הפקדה/משיכה והגבלת יתרה, שעון/תאורה, טלפון, שמירה/טעינה והתאוששות משדות פגומים.")
	quit(0)

func _fail(message: String) -> void:
	push_error(message)
	quit(1)
