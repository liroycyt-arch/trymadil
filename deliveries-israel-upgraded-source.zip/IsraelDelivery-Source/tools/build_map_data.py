#!/usr/bin/env python3
"""Convert a small OpenStreetMap Overpass extract into local game-space data."""
from __future__ import annotations
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "data" / "tel_aviv_osm_extract.json"
TARGET = ROOT / "data" / "tel_aviv_map.json"
ORIGIN_LAT = 32.0635
ORIGIN_LON = 34.7770
M_PER_DEG_LAT = 111_132.0
M_PER_DEG_LON = 111_320.0 * math.cos(math.radians(ORIGIN_LAT))

ROAD_WIDTHS = {
    "motorway": 15.0, "trunk": 13.0, "primary": 11.0,
    "secondary": 9.0, "tertiary": 7.5, "unclassified": 6.0,
    "residential": 6.0, "living_street": 5.0, "service": 4.0,
    "pedestrian": 4.0, "cycleway": 2.6, "footway": 2.0,
    "path": 1.8, "steps": 1.8, "track": 3.0,
}


def project(point: dict) -> list[float]:
    return [round((float(point["lon"]) - ORIGIN_LON) * M_PER_DEG_LON, 2),
            round(-(float(point["lat"]) - ORIGIN_LAT) * M_PER_DEG_LAT, 2)]


def main() -> None:
    osm = json.loads(SOURCE.read_text(encoding="utf-8"))
    roads, buildings, pois = [], [], []
    graph_nodes: list[list[float]] = []
    graph_edges: list[list] = []
    graph_index: dict[tuple[float, float], int] = {}
    named_roads = set()
    for element in osm.get("elements", []):
        tags = element.get("tags", {})
        geom = element.get("geometry") or []
        if element.get("type") != "way" and element.get("type") != "node":
            continue
        if "highway" in tags and element.get("type") == "way" and len(geom) >= 2:
            kind = tags["highway"]
            pts = [project(p) for p in geom]
            name = tags.get("name", tags.get("name:he", "רחוב ללא שם"))
            named_roads.add(name)
            one_way = tags.get("oneway", "no")
            indexes = []
            for point, xy in zip(geom, pts):
                key = (round(float(point["lat"]), 7), round(float(point["lon"]), 7))
                if key not in graph_index:
                    graph_index[key] = len(graph_nodes)
                    graph_nodes.append(xy)
                indexes.append(graph_index[key])
            reverse_only = one_way == "-1"
            roads.append({"name": name, "kind": kind, "oneway": tags.get("oneway") in ("yes", "1", "true"),
                          "width": ROAD_WIDTHS.get(kind, 5.0), "points": pts})
            for j in range(len(indexes) - 1):
                a, b = indexes[j], indexes[j + 1]
                length = round(math.dist(pts[j], pts[j + 1]), 2)
                if reverse_only:
                    graph_edges.append([b, a, name, length])
                else:
                    graph_edges.append([a, b, name, length])
                    if one_way not in ("yes", "1", "true"):
                        graph_edges.append([b, a, name, length])
        elif "building" in tags and element.get("type") == "way" and len(geom) >= 4:
            pts = [project(p) for p in geom]
            xs, zs = [p[0] for p in pts], [p[1] for p in pts]
            width, depth = max(xs) - min(xs), max(zs) - min(zs)
            if width < 2.3 or depth < 2.3 or width > 100 or depth > 100:
                continue
            levels = tags.get("building:levels")
            try:
                height = min(50.0, max(4.0, float(levels) * 3.0)) if levels else float(tags.get("height", 10.0))
            except (ValueError, TypeError):
                height = 10.0
            buildings.append({"center": [round((min(xs)+max(xs))/2,2), round((min(zs)+max(zs))/2,2)],
                              "size": [round(width,2), round(depth,2)], "height": round(min(50.0,max(4.0,height)),2),
                              "type": tags.get("building", "yes"), "name": tags.get("name", tags.get("name:he", ""))})
        elif element.get("type") == "node" and ("shop" in tags or tags.get("amenity") in {"restaurant", "cafe", "bank", "pharmacy", "fast_food"}):
            category = tags.get("amenity", tags.get("shop", "עסק"))
            name = tags.get("name", tags.get("name:he", "עסק מקומי"))
            pois.append({"name": name, "category": category, "position": project(element)})
    output = {
        "source": "© OpenStreetMap contributors",
        "license": "Open Database License (ODbL) 1.0; https://www.openstreetmap.org/copyright",
        "origin": {"lat": ORIGIN_LAT, "lon": ORIGIN_LON},
        "bounds": {"south": 32.0555, "west": 34.7665, "north": 32.0725, "east": 34.7875},
        "roads": roads, "buildings": buildings, "pois": pois,
        "graph_nodes": graph_nodes, "graph_edges": graph_edges,
    }
    TARGET.write_text(json.dumps(output, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    print(f"roads={len(roads)} buildings={len(buildings)} pois={len(pois)} graph_nodes={len(graph_nodes)} graph_edges={len(graph_edges)} named_streets={len(named_roads)} bytes={TARGET.stat().st_size}")
    print("sample streets:", ", ".join(sorted(x for x in named_roads if x != "רחוב ללא שם")[:40]))
    print("sample POIs:", ", ".join(p["name"] for p in pois[:25]))

if __name__ == "__main__":
    main()
