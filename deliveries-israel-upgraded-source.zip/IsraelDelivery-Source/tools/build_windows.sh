#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
GODOT_BIN="${GODOT_BIN:-godot}"
cd "$ROOT"
mkdir -p build/windows dist
if ! command -v "$GODOT_BIN" >/dev/null 2>&1; then
  echo "Godot 4.7.2 is required. Set GODOT_BIN to its executable." >&2
  exit 2
fi
if ! command -v makensis >/dev/null 2>&1; then
  echo "NSIS (makensis) is required to create the setup EXE." >&2
  exit 2
fi
"$GODOT_BIN" --headless --path "$ROOT" --editor --quit
"$GODOT_BIN" --headless --path "$ROOT" --script res://tests/smoke_test.gd
"$GODOT_BIN" --headless --path "$ROOT" --export-release "Windows Desktop" "$ROOT/build/windows/IsraelDelivery.exe"
test -s "$ROOT/build/windows/IsraelDelivery.exe"
makensis -V2 "$ROOT/installer.nsi"
test -s "$ROOT/dist/IsraelDelivery-Setup.exe"
printf 'Game EXE: %s\nSetup EXE: %s\n' "$ROOT/build/windows/IsraelDelivery.exe" "$ROOT/dist/IsraelDelivery-Setup.exe"
