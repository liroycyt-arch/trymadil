# נתוני מפה

תת־אזור מקומי במרכז תל אביב, מלב העיר ועד אזור פלורנטין/איילון, לפי תיבת גבולות מקורבת: 32.0555–32.0725° N, 34.7665–34.7875° E. הנתונים הורדו ב־22 באוקטובר 2026 מ־Overpass API של OpenStreetMap ומשמשים כנתוני רחובות, מבנים ונקודות עניין במשחק.

מקור ורישיון: © OpenStreetMap contributors, Open Database License (ODbL) 1.0. https://www.openstreetmap.org/copyright

`tel_aviv_osm_extract.json` הוא נתון המקור; `tel_aviv_map.json` הוא עיבוד מקומי המצורף למשחק. פרטי הייחוס והרישיון מופיעים גם ב־`OPEN_DATA_NOTICES.md` ובממשק המשחק.
