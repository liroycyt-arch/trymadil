Unicode true
!include "MUI2.nsh"

Name "משלוחים בישראל"
OutFile "dist/IsraelDelivery-Setup.exe"
InstallDir "$LOCALAPPDATA\Programs\IsraelDelivery"
InstallDirRegKey HKCU "Software\משלוחים בישראל" "InstallDir"
RequestExecutionLevel user
SetCompressor /SOLID lzma
Icon "assets/icons/game_icon.ico"
UninstallIcon "assets/icons/game_icon.ico"

!define MUI_ABORTWARNING
!define MUI_ICON "assets/icons/game_icon.ico"
!define MUI_UNICON "assets/icons/game_icon.ico"
!define MUI_WELCOMEPAGE_TITLE "התקנת משלוחים בישראל"
!define MUI_WELCOMEPAGE_TEXT "אשף זה יתקין את משחק המחשב משלוחים בישראל בחשבון Windows הנוכחי. המשחק פועל כיישום עצמאי ואינו דורש דפדפן."
!define MUI_FINISHPAGE_TITLE "ההתקנה הושלמה"
!define MUI_FINISHPAGE_TEXT "משלוחים בישראל הותקן. אפשר לפתוח את המשחק מקיצור הדרך בשולחן העבודה או בתפריט התחל."
!define MUI_FINISHPAGE_RUN "$INSTDIR\IsraelDelivery.exe"
!define MUI_FINISHPAGE_RUN_TEXT "הפעל עכשיו את המשחק"

!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "Hebrew"

Section "משחק משלוחים בישראל" SEC_GAME
  SectionIn RO
  SetOutPath "$INSTDIR"
  File "build/windows/IsraelDelivery.exe"
  File /oname=README_HE.txt "README_HE.md"
  File "OPEN_DATA_NOTICES.md"
  File /oname=Godot-LICENSE.txt "THIRD_PARTY/Godot-LICENSE.txt"
  File /oname=DejaVu-LICENSE.txt "assets/fonts/LICENSE-DejaVu.txt"
  CreateDirectory "$INSTDIR\data"
  SetOutPath "$INSTDIR\data"
  File "data/tel_aviv_osm_extract.json"
  File "data/tel_aviv_map.json"
  SetOutPath "$INSTDIR"

  WriteRegStr HKCU "Software\משלוחים בישראל" "InstallDir" "$INSTDIR"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\IsraelDelivery" "DisplayName" "משלוחים בישראל"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\IsraelDelivery" "UninstallString" '"$INSTDIR\Uninstall.exe"'
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\IsraelDelivery" "DisplayIcon" "$INSTDIR\IsraelDelivery.exe"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\IsraelDelivery" "Publisher" "משלוחים בישראל"
  WriteUninstaller "$INSTDIR\Uninstall.exe"

  CreateDirectory "$SMPROGRAMS\משלוחים בישראל"
  CreateShortcut "$SMPROGRAMS\משלוחים בישראל\משלוחים בישראל.lnk" "$INSTDIR\IsraelDelivery.exe" "" "$INSTDIR\IsraelDelivery.exe" 0
  CreateShortcut "$SMPROGRAMS\משלוחים בישראל\הוראות משחק.lnk" "$INSTDIR\README_HE.txt"
  CreateShortcut "$DESKTOP\משלוחים בישראל.lnk" "$INSTDIR\IsraelDelivery.exe" "" "$INSTDIR\IsraelDelivery.exe" 0
SectionEnd

Section "Uninstall"
  Delete "$DESKTOP\משלוחים בישראל.lnk"
  Delete "$SMPROGRAMS\משלוחים בישראל\משלוחים בישראל.lnk"
  Delete "$SMPROGRAMS\משלוחים בישראל\הוראות משחק.lnk"
  RMDir "$SMPROGRAMS\משלוחים בישראל"
  DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\IsraelDelivery"
  DeleteRegKey HKCU "Software\משלוחים בישראל"
  RMDir /r "$INSTDIR"
SectionEnd
